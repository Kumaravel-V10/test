'use client'

import { useState } from 'react'
import { AppLayout } from '@/components/app-layout'
import { useSettingsStore, useUIStore } from '@/lib/stores'
import { TOOLS } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { Save, RotateCcw, Zap, FlaskConical, Shield, Globe } from 'lucide-react'
import { cn } from '@/lib/utils'

const categoryIcons = {
  performance: Zap,
  functional: FlaskConical,
  security: Shield,
  api: Globe,
}

export default function ConfigPage() {
  const { toolConfigs, updateToolConfig } = useSettingsStore()
  const { addToast } = useUIStore()
  
  const [localConfigs, setLocalConfigs] = useState(
    toolConfigs.reduce((acc, tc) => {
      acc[tc.tool] = { ...tc.config }
      return acc
    }, {} as Record<string, Record<string, unknown>>)
  )

  const updateLocalConfig = (tool: string, key: string, value: unknown) => {
    setLocalConfigs(prev => ({
      ...prev,
      [tool]: { ...prev[tool], [key]: value }
    }))
  }

  const handleSave = () => {
    Object.entries(localConfigs).forEach(([tool, config]) => {
      updateToolConfig(tool as typeof TOOLS[number]['id'], { config })
    })
    addToast('Configuration saved', 'success')
  }

  const handleReset = () => {
    const defaults = {
      k6: { vus: 10, duration: '30s' },
      playwright: { browser: 'chromium', headless: true },
      zap: { scanMode: 'baseline' },
      newman: { iterationCount: 1 },
      artillery: { duration: 60, arrivalRate: 5 },
      lighthouse: { categories: ['performance', 'accessibility'] },
      trivy: { severity: 'HIGH,CRITICAL' },
      semgrep: { rules: 'auto' },
    }
    setLocalConfigs(defaults)
    addToast('Configuration reset to defaults', 'info')
  }

  return (
    <AppLayout title="Test Configuration">
      <div className="flex items-center justify-between mb-6">
        <p className="text-sm text-muted-foreground">
          Configure default settings for each testing tool
        </p>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="gap-2" onClick={handleReset}>
            <RotateCcw className="w-4 h-4" />
            Reset
          </Button>
          <Button className="gap-2" onClick={handleSave}>
            <Save className="w-4 h-4" />
            Save Changes
          </Button>
        </div>
      </div>

      <div className="max-w-3xl">
        <Accordion type="multiple" defaultValue={['k6']} className="space-y-4">
          {TOOLS.map((tool) => {
            const Icon = categoryIcons[tool.category]
            const config = localConfigs[tool.id] || {}

            return (
              <AccordionItem
                key={tool.id}
                value={tool.id}
                className="border border-border rounded-lg bg-card overflow-hidden"
              >
                <AccordionTrigger className="px-4 py-3 hover:no-underline hover:bg-secondary/50">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      'w-8 h-8 rounded flex items-center justify-center',
                      tool.category === 'performance' && 'bg-chart-1/15 text-chart-1',
                      tool.category === 'functional' && 'bg-chart-2/15 text-chart-2',
                      tool.category === 'security' && 'bg-chart-4/15 text-chart-4',
                      tool.category === 'api' && 'bg-chart-5/15 text-chart-5'
                    )}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                      <span className="font-medium text-foreground">{tool.name}</span>
                      <span className="ml-2 text-xs text-muted-foreground">
                        {tool.description}
                      </span>
                    </div>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <div className="space-y-4 pt-2">
                    {/* k6 Config */}
                    {tool.id === 'k6' && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="k6-vus" className="text-xs">Virtual Users</Label>
                            <Input
                              id="k6-vus"
                              type="number"
                              min={1}
                              max={1000}
                              value={config.vus as number || 10}
                              onChange={(e) => updateLocalConfig('k6', 'vus', parseInt(e.target.value))}
                              className="bg-input"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="k6-duration" className="text-xs">Duration</Label>
                            <Input
                              id="k6-duration"
                              value={config.duration as string || '30s'}
                              onChange={(e) => updateLocalConfig('k6', 'duration', e.target.value)}
                              className="bg-input"
                            />
                          </div>
                        </div>
                      </>
                    )}

                    {/* Playwright Config */}
                    {tool.id === 'playwright' && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label className="text-xs">Browser</Label>
                            <Select
                              value={config.browser as string || 'chromium'}
                              onValueChange={(v) => updateLocalConfig('playwright', 'browser', v)}
                            >
                              <SelectTrigger className="bg-input">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="chromium">Chromium</SelectItem>
                                <SelectItem value="firefox">Firefox</SelectItem>
                                <SelectItem value="webkit">WebKit</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label className="text-xs">Headless Mode</Label>
                            <div className="flex items-center gap-2 h-10">
                              <Switch
                                checked={config.headless as boolean ?? true}
                                onCheckedChange={(c) => updateLocalConfig('playwright', 'headless', c)}
                              />
                            </div>
                          </div>
                        </div>
                      </>
                    )}

                    {/* ZAP Config */}
                    {tool.id === 'zap' && (
                      <div className="space-y-2">
                        <Label className="text-xs">Scan Mode</Label>
                        <Select
                          value={config.scanMode as string || 'baseline'}
                          onValueChange={(v) => updateLocalConfig('zap', 'scanMode', v)}
                        >
                          <SelectTrigger className="bg-input">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="baseline">Baseline (Fast)</SelectItem>
                            <SelectItem value="full">Full Scan</SelectItem>
                            <SelectItem value="api">API Scan</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {/* Newman Config */}
                    {tool.id === 'newman' && (
                      <div className="space-y-2">
                        <Label htmlFor="newman-iter" className="text-xs">Iteration Count</Label>
                        <Input
                          id="newman-iter"
                          type="number"
                          min={1}
                          max={100}
                          value={config.iterationCount as number || 1}
                          onChange={(e) => updateLocalConfig('newman', 'iterationCount', parseInt(e.target.value))}
                          className="bg-input"
                        />
                      </div>
                    )}

                    {/* Artillery Config */}
                    {tool.id === 'artillery' && (
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="artillery-dur" className="text-xs">Duration (seconds)</Label>
                          <Input
                            id="artillery-dur"
                            type="number"
                            min={1}
                            max={3600}
                            value={config.duration as number || 60}
                            onChange={(e) => updateLocalConfig('artillery', 'duration', parseInt(e.target.value))}
                            className="bg-input"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="artillery-rate" className="text-xs">Arrival Rate</Label>
                          <Input
                            id="artillery-rate"
                            type="number"
                            min={1}
                            max={100}
                            value={config.arrivalRate as number || 5}
                            onChange={(e) => updateLocalConfig('artillery', 'arrivalRate', parseInt(e.target.value))}
                            className="bg-input"
                          />
                        </div>
                      </div>
                    )}

                    {/* Lighthouse Config */}
                    {tool.id === 'lighthouse' && (
                      <div className="space-y-2">
                        <Label className="text-xs">Categories</Label>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {['performance', 'accessibility', 'best-practices', 'seo'].map((cat) => {
                            const categories = (config.categories as string[]) || ['performance', 'accessibility']
                            const isActive = categories.includes(cat)
                            
                            return (
                              <button
                                key={cat}
                                type="button"
                                onClick={() => {
                                  const newCats = isActive
                                    ? categories.filter(c => c !== cat)
                                    : [...categories, cat]
                                  updateLocalConfig('lighthouse', 'categories', newCats)
                                }}
                                className={`px-3 py-1 text-xs rounded-full transition-colors ${
                                  isActive
                                    ? 'bg-accent text-accent-foreground'
                                    : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                                }`}
                              >
                                {cat}
                              </button>
                            )
                          })}
                        </div>
                      </div>
                    )}

                    {/* Trivy Config */}
                    {tool.id === 'trivy' && (
                      <div className="space-y-2">
                        <Label className="text-xs">Minimum Severity</Label>
                        <Select
                          value={config.severity as string || 'HIGH,CRITICAL'}
                          onValueChange={(v) => updateLocalConfig('trivy', 'severity', v)}
                        >
                          <SelectTrigger className="bg-input">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="CRITICAL">Critical Only</SelectItem>
                            <SelectItem value="HIGH,CRITICAL">High & Critical</SelectItem>
                            <SelectItem value="MEDIUM,HIGH,CRITICAL">Medium+</SelectItem>
                            <SelectItem value="LOW,MEDIUM,HIGH,CRITICAL">All</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {/* Semgrep Config */}
                    {tool.id === 'semgrep' && (
                      <div className="space-y-2">
                        <Label className="text-xs">Rule Set</Label>
                        <Select
                          value={config.rules as string || 'auto'}
                          onValueChange={(v) => updateLocalConfig('semgrep', 'rules', v)}
                        >
                          <SelectTrigger className="bg-input">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="auto">Auto-detect</SelectItem>
                            <SelectItem value="p/security-audit">Security Audit</SelectItem>
                            <SelectItem value="p/ci">CI Rules</SelectItem>
                            <SelectItem value="p/default">Default</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>
                </AccordionContent>
              </AccordionItem>
            )
          })}
        </Accordion>
      </div>
    </AppLayout>
  )
}
