'use client'

import { AppLayout } from '@/components/app-layout'
import { useSettingsStore, useUIStore } from '@/lib/stores'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Save, Wifi, WifiOff, Server, FileText, AlertCircle } from 'lucide-react'
import { cn } from '@/lib/utils'

export default function SettingsPage() {
  const { localMode, apiBaseUrl, runtimeNotes, updateSettings } = useSettingsStore()
  const { addToast } = useUIStore()

  const handleSave = () => {
    addToast('Settings saved', 'success')
  }

  return (
    <AppLayout title="Settings">
      <div className="max-w-2xl space-y-6">
        {/* Local Mode */}
        <Card className="bg-card border-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base flex items-center gap-2">
                  {localMode ? (
                    <Wifi className="w-4 h-4 text-status-pass" />
                  ) : (
                    <WifiOff className="w-4 h-4 text-status-warn" />
                  )}
                  Runtime Mode
                </CardTitle>
                <CardDescription>
                  Toggle between local and remote execution
                </CardDescription>
              </div>
              <Badge
                variant="outline"
                className={cn(
                  localMode
                    ? 'border-status-pass/30 text-status-pass'
                    : 'border-status-warn/30 text-status-warn'
                )}
              >
                {localMode ? 'Local' : 'Remote'}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/50">
              <div>
                <p className="text-sm font-medium text-foreground">Local Mode</p>
                <p className="text-xs text-muted-foreground">
                  Run k6 tests locally without requiring the full worker stack
                </p>
              </div>
              <Switch
                checked={localMode}
                onCheckedChange={(checked) => updateSettings({ localMode: checked })}
              />
            </div>

            {localMode && (
              <div className="p-4 rounded-lg bg-status-pass/10 border border-status-pass/20">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-4 h-4 text-status-pass mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-status-pass">Local Mode Active</p>
                    <p className="text-xs text-status-pass/80 mt-1">
                      Only k6 tests are available in local mode. Other testing tools
                      require the full worker stack to be running.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {!localMode && (
              <div className="p-4 rounded-lg bg-status-warn/10 border border-status-warn/20">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-4 h-4 text-status-warn mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-status-warn">Remote Mode</p>
                    <p className="text-xs text-status-warn/80 mt-1">
                      All testing tools are available but require connection to the
                      QUBE backend service.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* API Configuration */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Server className="w-4 h-4" />
              API Configuration
            </CardTitle>
            <CardDescription>
              Configure the backend API endpoint
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="apiUrl">API Base URL</Label>
              <Input
                id="apiUrl"
                value={apiBaseUrl}
                onChange={(e) => updateSettings({ apiBaseUrl: e.target.value })}
                placeholder="http://localhost:8080"
                className="bg-input font-mono"
              />
              <p className="text-xs text-muted-foreground">
                The base URL for the QUBE backend API
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Runtime Notes */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Runtime Notes
            </CardTitle>
            <CardDescription>
              Add notes or reminders about your testing setup
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              value={runtimeNotes}
              onChange={(e) => updateSettings({ runtimeNotes: e.target.value })}
              placeholder="Add any notes about your current testing configuration..."
              className="bg-input min-h-[120px] resize-none"
            />
          </CardContent>
        </Card>

        {/* Local Mode Features */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-base">Feature Availability</CardTitle>
            <CardDescription>
              Features available based on current mode
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <FeatureRow
                feature="k6 Load Testing"
                available
                description="Always available"
              />
              <FeatureRow
                feature="Playwright E2E"
                available={!localMode}
                description={localMode ? 'Requires remote mode' : 'Available'}
              />
              <FeatureRow
                feature="ZAP Security Scan"
                available={!localMode}
                description={localMode ? 'Requires remote mode' : 'Available'}
              />
              <FeatureRow
                feature="Newman API Tests"
                available={!localMode}
                description={localMode ? 'Requires remote mode' : 'Available'}
              />
              <FeatureRow
                feature="Artillery Load Testing"
                available={!localMode}
                description={localMode ? 'Requires remote mode' : 'Available'}
              />
              <FeatureRow
                feature="Lighthouse Audits"
                available={!localMode}
                description={localMode ? 'Requires remote mode' : 'Available'}
              />
              <FeatureRow
                feature="Trivy Vulnerability Scan"
                available={!localMode}
                description={localMode ? 'Requires remote mode' : 'Available'}
              />
              <FeatureRow
                feature="Semgrep Code Analysis"
                available={!localMode}
                description={localMode ? 'Requires remote mode' : 'Available'}
              />
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button onClick={handleSave} className="gap-2">
            <Save className="w-4 h-4" />
            Save Settings
          </Button>
        </div>
      </div>
    </AppLayout>
  )
}

interface FeatureRowProps {
  feature: string
  available: boolean
  description: string
}

function FeatureRow({ feature, available, description }: FeatureRowProps) {
  return (
    <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
      <div>
        <p className="text-sm font-medium text-foreground">{feature}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      <Badge
        variant="outline"
        className={cn(
          'text-xs',
          available
            ? 'border-status-pass/30 text-status-pass'
            : 'border-muted-foreground/30 text-muted-foreground'
        )}
      >
        {available ? 'Available' : 'Disabled'}
      </Badge>
    </div>
  )
}
