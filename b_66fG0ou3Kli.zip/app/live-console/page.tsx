'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { AppLayout } from '@/components/app-layout'
import { StageProgressStrip } from '@/components/stage-progress-strip'
import { LogTerminal } from '@/components/log-terminal'
import { RunMetaCard } from '@/components/run-meta-card'
import { GateBadge } from '@/components/badges'
import { EmptyState } from '@/components/states'
import { useRunStore } from '@/lib/stores'
import { generateMockLogs } from '@/lib/mock-data'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { FileText, Shield, FileBarChart, Square, ExternalLink } from 'lucide-react'
import type { Run, LogEntry } from '@/lib/types'

export default function LiveConsolePage() {
  const { currentRun, logs, setCurrentRun, addLog, setLive } = useRunStore()
  const [simulatedRun, setSimulatedRun] = useState<Run | null>(null)

  // Simulate a running test for demo purposes
  useEffect(() => {
    if (!currentRun) {
      // Create a demo run if none exists
      const demoRun: Run = {
        id: `run-demo-${Date.now()}`,
        projectId: 'proj-1',
        projectName: 'ecommerce-api',
        branch: 'main',
        status: 'running',
        selectedTools: ['k6', 'playwright', 'trivy'],
        stages: [
          { name: 'k6', tool: 'k6', status: 'passed', duration: 45000 },
          { name: 'playwright', tool: 'playwright', status: 'running' },
          { name: 'trivy', tool: 'trivy', status: 'pending' },
        ],
        createdAt: new Date().toISOString(),
        startedAt: new Date().toISOString(),
      }
      setSimulatedRun(demoRun)
      setLive(true)

      // Add mock logs progressively
      const mockLogs = generateMockLogs()
      let logIndex = 0

      const logInterval = setInterval(() => {
        if (logIndex < mockLogs.length) {
          addLog(mockLogs[logIndex])
          logIndex++
        }
      }, 500)

      // Simulate stage completion
      const stageTimer = setTimeout(() => {
        setSimulatedRun((prev) => {
          if (!prev) return null
          return {
            ...prev,
            status: 'completed',
            gate: 'PASS',
            stages: prev.stages.map((s) =>
              s.status === 'running'
                ? { ...s, status: 'passed', duration: 90000 }
                : s.status === 'pending'
                ? { ...s, status: 'passed', duration: 12000 }
                : s
            ),
            completedAt: new Date().toISOString(),
            duration: 147000,
          }
        })
        setLive(false)
      }, 10000)

      return () => {
        clearInterval(logInterval)
        clearTimeout(stageTimer)
      }
    }
  }, [currentRun, setCurrentRun, addLog, setLive])

  const run = currentRun || simulatedRun

  if (!run) {
    return (
      <AppLayout title="Live Console">
        <EmptyState
          icon={<FileBarChart className="w-6 h-6 text-muted-foreground" />}
          title="No active run"
          description="Start a new run to see live output here"
          action={{ label: 'New Run', onClick: () => {} }}
        />
      </AppLayout>
    )
  }

  return (
    <AppLayout title="Live Console">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-3 space-y-4">
          {/* Stage Progress */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Stage Progress</CardTitle>
                {run.status === 'running' && (
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-status-running animate-pulse" />
                    <span className="text-xs text-status-running">Running</span>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <StageProgressStrip stages={run.stages} />
            </CardContent>
          </Card>

          {/* Log Terminal */}
          <LogTerminal logs={logs} className="h-[500px]" />

          {/* Action Buttons */}
          {run.status === 'completed' && (
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <div className="flex flex-wrap items-center gap-3">
                  <Link href={`/reports/${run.id}`}>
                    <Button variant="outline" className="gap-2">
                      <FileText className="w-4 h-4" />
                      Merged Report
                    </Button>
                  </Link>
                  <Link href={`/reports/${run.id}?tab=gate`}>
                    <Button variant="outline" className="gap-2">
                      <Shield className="w-4 h-4" />
                      Gate Report
                    </Button>
                  </Link>
                  <Button variant="outline" className="gap-2">
                    <ExternalLink className="w-4 h-4" />
                    HTML Report
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {run.status === 'running' && (
            <Card className="bg-card border-border">
              <CardContent className="p-4">
                <Button
                  variant="destructive"
                  className="gap-2"
                  onClick={() => {
                    setSimulatedRun((prev) =>
                      prev ? { ...prev, status: 'cancelled' } : null
                    )
                    setLive(false)
                  }}
                >
                  <Square className="w-4 h-4" />
                  Cancel Run
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Run Meta */}
          <RunMetaCard run={run} />

          {/* Gate Status Card */}
          {run.gate && (
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Gate Decision</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center py-4">
                  <GateBadge gate={run.gate} size="lg" />
                  <p className="text-sm text-muted-foreground mt-3 text-center">
                    {run.gate === 'PASS' && 'All quality gates passed'}
                    {run.gate === 'WARN' && 'Some warnings detected'}
                    {run.gate === 'BLOCK' && 'Quality gates failed'}
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </AppLayout>
  )
}
