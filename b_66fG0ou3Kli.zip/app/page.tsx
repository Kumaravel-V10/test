'use client'

import Link from 'next/link'
import { AppLayout } from '@/components/app-layout'
import { GateBadge, RunStatusBadge } from '@/components/badges'
import { LoadingState, EmptyState, ErrorState } from '@/components/states'
import { useProjects, useRuns } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Plus, Play, FolderKanban, Activity, GitBranch, Clock } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

export default function DashboardPage() {
  const { data: projects, isLoading: projectsLoading, error: projectsError } = useProjects()
  const { data: runs, isLoading: runsLoading, error: runsError } = useRuns()

  const recentRuns = runs?.slice(0, 5) || []
  const runningRuns = runs?.filter(r => r.status === 'running') || []

  return (
    <AppLayout title="Dashboard">
      {/* Quick Actions */}
      <div className="flex items-center gap-3 mb-8">
        <Link href="/projects/new">
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            New Project
          </Button>
        </Link>
        <Link href="/new-run">
          <Button variant="outline" className="gap-2">
            <Play className="w-4 h-4" />
            New Run
          </Button>
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatsCard
          icon={<FolderKanban className="w-5 h-5" />}
          label="Total Projects"
          value={projects?.length || 0}
          loading={projectsLoading}
        />
        <StatsCard
          icon={<Activity className="w-5 h-5" />}
          label="Active Runs"
          value={runningRuns.length}
          loading={runsLoading}
          highlight={runningRuns.length > 0}
        />
        <StatsCard
          icon={<GitBranch className="w-5 h-5" />}
          label="Total Runs"
          value={runs?.length || 0}
          loading={runsLoading}
        />
        <StatsCard
          icon={<Clock className="w-5 h-5" />}
          label="This Week"
          value={runs?.filter(r => {
            const runDate = new Date(r.createdAt)
            const weekAgo = new Date()
            weekAgo.setDate(weekAgo.getDate() - 7)
            return runDate > weekAgo
          }).length || 0}
          loading={runsLoading}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Projects */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-base font-semibold">Projects</CardTitle>
            <Link href="/projects">
              <Button variant="ghost" size="sm" className="text-muted-foreground text-xs">
                View all
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {projectsLoading ? (
              <LoadingState message="Loading projects..." className="py-8" />
            ) : projectsError ? (
              <ErrorState message="Failed to load projects" className="py-8" />
            ) : !projects?.length ? (
              <EmptyState
                title="No projects yet"
                description="Create your first project to get started"
                action={{ label: 'New Project', onClick: () => {} }}
                className="py-8"
              />
            ) : (
              <div className="space-y-3">
                {projects.slice(0, 5).map((project) => (
                  <Link
                    key={project.id}
                    href={`/projects/${project.id}`}
                    className="block"
                  >
                    <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-8 h-8 rounded bg-accent/20 flex items-center justify-center flex-shrink-0">
                          <FolderKanban className="w-4 h-4 text-accent" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">
                            {project.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {project.sourceType === 'github' ? 'GitHub' : 'ZIP Upload'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {project.latestGate && (
                          <GateBadge gate={project.latestGate} size="sm" />
                        )}
                        {project.lastRunAt && (
                          <span className="text-xs text-muted-foreground hidden sm:block">
                            {formatDistanceToNow(new Date(project.lastRunAt), { addSuffix: true })}
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Runs */}
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-base font-semibold">Recent Runs</CardTitle>
            <Link href="/history">
              <Button variant="ghost" size="sm" className="text-muted-foreground text-xs">
                View all
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            {runsLoading ? (
              <LoadingState message="Loading runs..." className="py-8" />
            ) : runsError ? (
              <ErrorState message="Failed to load runs" className="py-8" />
            ) : !recentRuns.length ? (
              <EmptyState
                title="No runs yet"
                description="Start a new run to see results here"
                action={{ label: 'New Run', onClick: () => {} }}
                className="py-8"
              />
            ) : (
              <div className="space-y-3">
                {recentRuns.map((run) => (
                  <Link
                    key={run.id}
                    href={run.status === 'running' ? '/live-console' : `/reports/${run.id}`}
                    className="block"
                  >
                    <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors">
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">
                          {run.projectName}
                        </p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                          <GitBranch className="w-3 h-3" />
                          {run.branch}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <RunStatusBadge status={run.status} />
                        {run.gate && <GateBadge gate={run.gate} size="sm" />}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  )
}

interface StatsCardProps {
  icon: React.ReactNode
  label: string
  value: number
  loading?: boolean
  highlight?: boolean
}

function StatsCard({ icon, label, value, loading, highlight }: StatsCardProps) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${highlight ? 'bg-status-running/15 text-status-running' : 'bg-accent/15 text-accent'}`}>
            {icon}
          </div>
          <div>
            <p className="text-2xl font-bold text-foreground">
              {loading ? '-' : value}
            </p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
