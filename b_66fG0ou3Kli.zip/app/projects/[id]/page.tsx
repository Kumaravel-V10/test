'use client'

import { use } from 'react'
import Link from 'next/link'
import { AppLayout } from '@/components/app-layout'
import { GateBadge, RunStatusBadge } from '@/components/badges'
import { LoadingState, EmptyState, ErrorState } from '@/components/states'
import { ZipUpload } from '@/components/zip-upload'
import { useProject, useRuns, useUploadSource } from '@/lib/api'
import { useUIStore } from '@/lib/stores'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { 
  ArrowLeft, 
  Play, 
  Github, 
  FileArchive, 
  GitBranch, 
  Clock, 
  ExternalLink,
  Upload
} from 'lucide-react'
import { formatDistanceToNow, format } from 'date-fns'
import { useRouter } from 'next/navigation'

export default function ProjectDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const { addToast } = useUIStore()
  const { data: project, isLoading: projectLoading, error: projectError } = useProject(id)
  const { data: runs, isLoading: runsLoading } = useRuns(id)
  const { trigger: uploadSource } = useUploadSource()

  const handleUpload = async (file: File) => {
    try {
      await uploadSource({ projectId: id, file })
      addToast('Source uploaded successfully', 'success')
    } catch {
      addToast('Upload failed', 'error')
      throw new Error('Upload failed')
    }
  }

  if (projectLoading) {
    return (
      <AppLayout title="Project">
        <LoadingState message="Loading project..." />
      </AppLayout>
    )
  }

  if (projectError || !project) {
    return (
      <AppLayout title="Project">
        <ErrorState message="Failed to load project" />
      </AppLayout>
    )
  }

  return (
    <AppLayout title={project.name}>
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="ghost"
          className="gap-2"
          onClick={() => router.push('/projects')}
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Projects
        </Button>

        <Link href={`/new-run?project=${id}`}>
          <Button className="gap-2">
            <Play className="w-4 h-4" />
            New Run
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Project Overview */}
          <Card className="bg-card border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-accent/15 flex items-center justify-center">
                    {project.sourceType === 'github' ? (
                      <Github className="w-6 h-6 text-accent" />
                    ) : (
                      <FileArchive className="w-6 h-6 text-accent" />
                    )}
                  </div>
                  <div>
                    <CardTitle className="text-lg">{project.name}</CardTitle>
                    <CardDescription>
                      {project.sourceType === 'github' ? 'GitHub Repository' : 'ZIP Upload'}
                    </CardDescription>
                  </div>
                </div>
                {project.latestGate && (
                  <GateBadge gate={project.latestGate} size="md" />
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Branch</span>
                  <div className="flex items-center gap-1.5 mt-1 text-foreground">
                    <GitBranch className="w-4 h-4" />
                    {project.branch || 'main'}
                  </div>
                </div>
                <div>
                  <span className="text-muted-foreground">Created</span>
                  <div className="flex items-center gap-1.5 mt-1 text-foreground">
                    <Clock className="w-4 h-4" />
                    {format(new Date(project.createdAt), 'MMM d, yyyy')}
                  </div>
                </div>
                {project.repoUrl && (
                  <div className="col-span-2">
                    <span className="text-muted-foreground">Repository</span>
                    <div className="mt-1">
                      <a
                        href={project.repoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 text-accent hover:underline"
                      >
                        {project.repoUrl}
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Recent Runs */}
          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Recent Runs</CardTitle>
              <Link href={`/history?project=${id}`}>
                <Button variant="ghost" size="sm" className="text-xs text-muted-foreground">
                  View All
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {runsLoading ? (
                <LoadingState message="Loading runs..." className="py-8" />
              ) : !runs?.length ? (
                <EmptyState
                  title="No runs yet"
                  description="Start a new run to test your project"
                  className="py-8"
                />
              ) : (
                <div className="space-y-3">
                  {runs.slice(0, 5).map((run) => (
                    <Link
                      key={run.id}
                      href={run.status === 'running' ? '/live-console' : `/reports/${run.id}`}
                      className="block"
                    >
                      <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="text-xs text-muted-foreground font-mono">
                            {run.id.slice(0, 8)}
                          </div>
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <GitBranch className="w-3 h-3" />
                            {run.branch}
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <RunStatusBadge status={run.status} />
                          {run.gate && <GateBadge gate={run.gate} size="sm" />}
                          <span className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(run.createdAt), { addSuffix: true })}
                          </span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Upload (for ZIP projects) */}
          {project.sourceType === 'zip' && (
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Upload className="w-4 h-4" />
                  Update Source
                </CardTitle>
                <CardDescription>Upload a new ZIP file to update the source code</CardDescription>
              </CardHeader>
              <CardContent>
                <ZipUpload onUpload={handleUpload} />
              </CardContent>
            </Card>
          )}

          {/* Quick Stats */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-base">Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Total Runs</span>
                  <span className="text-sm font-medium text-foreground">{runs?.length || 0}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Pass Rate</span>
                  <span className="text-sm font-medium text-status-pass">
                    {runs?.length
                      ? `${Math.round((runs.filter(r => r.gate === 'PASS').length / runs.length) * 100)}%`
                      : '-'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Last Run</span>
                  <span className="text-sm text-foreground">
                    {project.lastRunAt
                      ? formatDistanceToNow(new Date(project.lastRunAt), { addSuffix: true })
                      : 'Never'}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  )
}
