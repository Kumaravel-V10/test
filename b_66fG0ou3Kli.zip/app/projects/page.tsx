'use client'

import Link from 'next/link'
import { AppLayout } from '@/components/app-layout'
import { GateBadge } from '@/components/badges'
import { LoadingState, EmptyState, ErrorState } from '@/components/states'
import { useProjects } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Plus, Search, FolderKanban, Github, FileArchive, GitBranch, Clock } from 'lucide-react'
import { useState } from 'react'
import { formatDistanceToNow } from 'date-fns'

export default function ProjectsPage() {
  const { data: projects, isLoading, error } = useProjects()
  const [search, setSearch] = useState('')

  const filteredProjects = projects?.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <AppLayout
      title="Projects"
      headerContent={
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search projects..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-64 pl-9 bg-input"
            />
          </div>
        </div>
      }
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-muted-foreground text-sm">
            {projects?.length || 0} projects total
          </p>
        </div>
        <Link href="/projects/new">
          <Button className="gap-2">
            <Plus className="w-4 h-4" />
            New Project
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <LoadingState message="Loading projects..." />
      ) : error ? (
        <ErrorState message="Failed to load projects" />
      ) : !filteredProjects?.length ? (
        <EmptyState
          title={search ? 'No projects found' : 'No projects yet'}
          description={search ? 'Try a different search term' : 'Create your first project to get started'}
          action={!search ? { label: 'New Project', onClick: () => {} } : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProjects.map((project, index) => (
            <Link key={project.id} href={`/projects/${project.id}`}>
              <Card 
                className="bg-card border-border hover:border-accent/50 transition-all cursor-pointer animate-slide-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                      {project.sourceType === 'github' ? (
                        <Github className="w-5 h-5 text-accent" />
                      ) : (
                        <FileArchive className="w-5 h-5 text-accent" />
                      )}
                    </div>
                    {project.latestGate && (
                      <GateBadge gate={project.latestGate} size="sm" />
                    )}
                  </div>

                  <h3 className="text-base font-semibold text-foreground mb-1 truncate">
                    {project.name}
                  </h3>
                  
                  <p className="text-xs text-muted-foreground mb-4">
                    {project.sourceType === 'github' ? 'GitHub Repository' : 'ZIP Upload'}
                  </p>

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <GitBranch className="w-3 h-3" />
                      {project.branch || 'main'}
                    </div>
                    {project.lastRunAt && (
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatDistanceToNow(new Date(project.lastRunAt), { addSuffix: true })}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </AppLayout>
  )
}
