'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { AppLayout } from '@/components/app-layout'
import { ZipUpload } from '@/components/zip-upload'
import { useCreateProject, useUploadSource } from '@/lib/api'
import { useUIStore } from '@/lib/stores'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Github, FileArchive, ArrowLeft, Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { SourceType } from '@/lib/types'

export default function NewProjectPage() {
  const router = useRouter()
  const { addToast } = useUIStore()
  const { trigger: createProject, isMutating: creating } = useCreateProject()
  const { trigger: uploadSource } = useUploadSource()

  const [sourceType, setSourceType] = useState<SourceType>('zip')
  const [name, setName] = useState('')
  const [repoUrl, setRepoUrl] = useState('')
  const [branch, setBranch] = useState('main')
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!name.trim()) {
      addToast('Please enter a project name', 'error')
      return
    }

    if (sourceType === 'github' && !repoUrl.trim()) {
      addToast('Please enter a repository URL', 'error')
      return
    }

    try {
      const project = await createProject({
        name: name.trim(),
        sourceType,
        repoUrl: sourceType === 'github' ? repoUrl.trim() : undefined,
        branch: sourceType === 'github' ? branch : 'uploaded',
      })

      if (sourceType === 'zip' && uploadedFile && project) {
        await uploadSource({ projectId: project.id, file: uploadedFile })
      }

      addToast('Project created successfully', 'success')
      router.push(`/projects/${project?.id}`)
    } catch {
      addToast('Failed to create project', 'error')
    }
  }

  const handleUpload = async (file: File) => {
    setUploadedFile(file)
  }

  return (
    <AppLayout title="New Project">
      <Button
        variant="ghost"
        className="gap-2 mb-6"
        onClick={() => router.back()}
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </Button>

      <div className="max-w-2xl">
        <form onSubmit={handleSubmit}>
          {/* Project Name */}
          <Card className="bg-card border-border mb-6">
            <CardHeader>
              <CardTitle className="text-base">Project Name</CardTitle>
              <CardDescription>Choose a unique name for your project</CardDescription>
            </CardHeader>
            <CardContent>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="my-awesome-project"
                className="bg-input"
              />
            </CardContent>
          </Card>

          {/* Source Type */}
          <Card className="bg-card border-border mb-6">
            <CardHeader>
              <CardTitle className="text-base">Source Type</CardTitle>
              <CardDescription>Choose how to provide your source code</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setSourceType('zip')}
                  className={cn(
                    'flex flex-col items-center p-6 rounded-lg border-2 transition-all',
                    sourceType === 'zip'
                      ? 'border-accent bg-accent/10'
                      : 'border-border hover:border-muted-foreground/50'
                  )}
                >
                  <FileArchive className={cn(
                    'w-8 h-8 mb-3',
                    sourceType === 'zip' ? 'text-accent' : 'text-muted-foreground'
                  )} />
                  <span className="text-sm font-medium text-foreground">ZIP Upload</span>
                  <span className="text-xs text-muted-foreground mt-1">Upload a ZIP file</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSourceType('github')}
                  className={cn(
                    'flex flex-col items-center p-6 rounded-lg border-2 transition-all',
                    sourceType === 'github'
                      ? 'border-accent bg-accent/10'
                      : 'border-border hover:border-muted-foreground/50'
                  )}
                >
                  <Github className={cn(
                    'w-8 h-8 mb-3',
                    sourceType === 'github' ? 'text-accent' : 'text-muted-foreground'
                  )} />
                  <span className="text-sm font-medium text-foreground">GitHub</span>
                  <span className="text-xs text-muted-foreground mt-1">Connect a repository</span>
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Source Configuration */}
          {sourceType === 'github' ? (
            <Card className="bg-card border-border mb-6">
              <CardHeader>
                <CardTitle className="text-base">Repository Details</CardTitle>
                <CardDescription>Provide your GitHub repository information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="repoUrl">Repository URL</Label>
                  <Input
                    id="repoUrl"
                    value={repoUrl}
                    onChange={(e) => setRepoUrl(e.target.value)}
                    placeholder="https://github.com/org/repo"
                    className="bg-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="branch">Branch</Label>
                  <Input
                    id="branch"
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                    placeholder="main"
                    className="bg-input"
                  />
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-card border-border mb-6">
              <CardHeader>
                <CardTitle className="text-base">Upload Source</CardTitle>
                <CardDescription>Upload your project as a ZIP file</CardDescription>
              </CardHeader>
              <CardContent>
                <ZipUpload onUpload={handleUpload} />
              </CardContent>
            </Card>
          )}

          {/* Submit */}
          <div className="flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.back()}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={creating}>
              {creating && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Create Project
            </Button>
          </div>
        </form>
      </div>
    </AppLayout>
  )
}
