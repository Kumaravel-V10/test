'use client'

import { useState, useEffect, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { AppLayout } from '@/components/app-layout'
import { StageSelector } from '@/components/stage-selector'
import { ToolConfigPanels } from '@/components/tool-config-panels'
import { LoadingState } from '@/components/states'
import { useProjects, useCreateRun } from '@/lib/api'
import { useSettingsStore, useRunStore, useUIStore } from '@/lib/stores'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Play, Loader2, ArrowLeft } from 'lucide-react'
import type { TestTool } from '@/lib/types'

function NewRunContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const preselectedProject = searchParams.get('project')
  
  const { localMode } = useSettingsStore()
  const { setCurrentRun, clearLogs, setLive } = useRunStore()
  const { addToast } = useUIStore()
  
  const { data: projects, isLoading: projectsLoading } = useProjects()
  const { trigger: createRun, isMutating: creating } = useCreateRun()

  const [projectId, setProjectId] = useState(preselectedProject || '')
  const [branch, setBranch] = useState('')
  const [selectedTools, setSelectedTools] = useState<TestTool[]>(['k6'])
  const [toolConfig, setToolConfig] = useState<Record<string, Record<string, unknown>>>({
    k6: { vus: 10, duration: '30s' },
  })

  // Set branch based on project
  useEffect(() => {
    if (projectId && projects) {
      const project = projects.find(p => p.id === projectId)
      if (project) {
        setBranch(project.sourceType === 'zip' ? 'uploaded' : project.branch || 'main')
      }
    }
  }, [projectId, projects])

  const selectedProject = projects?.find(p => p.id === projectId)

  const handleStartRun = async () => {
    if (!projectId) {
      addToast('Please select a project', 'error')
      return
    }

    if (selectedTools.length === 0) {
      addToast('Please select at least one testing tool', 'error')
      return
    }

    try {
      const run = await createRun({
        projectId,
        branch,
        tools: selectedTools,
        config: toolConfig,
      })

      if (run) {
        clearLogs()
        setCurrentRun(run)
        setLive(true)
        addToast('Run started successfully', 'success')
        router.push('/live-console')
      }
    } catch {
      addToast('Failed to start run', 'error')
    }
  }

  return (
    <AppLayout title="New Run">
      <Button
        variant="ghost"
        className="gap-2 mb-6"
        onClick={() => router.back()}
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </Button>

      <div className="max-w-4xl">
        {/* Project Selection */}
        <Card className="bg-card border-border mb-6">
          <CardHeader>
            <CardTitle className="text-base">Select Project</CardTitle>
            <CardDescription>Choose the project you want to test</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {projectsLoading ? (
              <LoadingState message="Loading projects..." className="py-4" />
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="project">Project</Label>
                  <Select value={projectId} onValueChange={setProjectId}>
                    <SelectTrigger id="project" className="bg-input">
                      <SelectValue placeholder="Select a project..." />
                    </SelectTrigger>
                    <SelectContent>
                      {projects?.map((project) => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.name} ({project.sourceType})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedProject && (
                  <div className="space-y-2">
                    <Label htmlFor="branch">Branch</Label>
                    <Input
                      id="branch"
                      value={branch}
                      onChange={(e) => setBranch(e.target.value)}
                      placeholder={selectedProject.sourceType === 'zip' ? 'uploaded' : 'main'}
                      disabled={selectedProject.sourceType === 'zip'}
                      className="bg-input"
                    />
                    {selectedProject.sourceType === 'zip' && (
                      <p className="text-xs text-muted-foreground">
                        ZIP source uses &ldquo;uploaded&rdquo; as the branch name
                      </p>
                    )}
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Tool Selection */}
        <Card className="bg-card border-border mb-6">
          <CardHeader>
            <CardTitle className="text-base">Select Testing Tools</CardTitle>
            <CardDescription>Choose which tools to include in this test run</CardDescription>
          </CardHeader>
          <CardContent>
            <StageSelector
              selected={selectedTools}
              onChange={setSelectedTools}
              localMode={localMode}
            />
          </CardContent>
        </Card>

        {/* Tool Configuration */}
        {selectedTools.length > 0 && (
          <Card className="bg-card border-border mb-6">
            <CardHeader>
              <CardTitle className="text-base">Tool Configuration</CardTitle>
              <CardDescription>Configure settings for selected tools</CardDescription>
            </CardHeader>
            <CardContent>
              <ToolConfigPanels
                selectedTools={selectedTools}
                config={toolConfig}
                onChange={setToolConfig}
              />
            </CardContent>
          </Card>
        )}

        {/* Run Summary & Start Button */}
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-foreground mb-1">Run Summary</h3>
                <p className="text-sm text-muted-foreground">
                  {selectedProject ? selectedProject.name : 'No project selected'}
                  {selectedTools.length > 0 && ` • ${selectedTools.length} tool${selectedTools.length > 1 ? 's' : ''} selected`}
                </p>
              </div>
              <Button
                onClick={handleStartRun}
                disabled={creating || !projectId || selectedTools.length === 0}
                className="gap-2"
                size="lg"
              >
                {creating ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
                Start Run
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  )
}

export default function NewRunPage() {
  return (
    <Suspense fallback={<AppLayout title="New Run"><LoadingState message="Loading..." /></AppLayout>}>
      <NewRunContent />
    </Suspense>
  )
}
