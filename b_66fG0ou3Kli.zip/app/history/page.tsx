'use client'

import { useState, Suspense } from 'react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { AppLayout } from '@/components/app-layout'
import { GateBadge, RunStatusBadge } from '@/components/badges'
import { LoadingState, EmptyState, ErrorState } from '@/components/states'
import { useRuns, useProjects } from '@/lib/api'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table'
import { Search, History, GitBranch } from 'lucide-react'
import { format, formatDistanceToNow } from 'date-fns'
import type { GateDecision, RunStatus } from '@/lib/types'

function HistoryContent() {
  const searchParams = useSearchParams()
  const projectFilter = searchParams.get('project') || ''
  
  const { data: runs, isLoading, error } = useRuns()
  const { data: projects } = useProjects()
  
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [gateFilter, setGateFilter] = useState<string>('all')
  const [projectId, setProjectId] = useState(projectFilter)

  const filteredRuns = runs?.filter(run => {
    if (search && !run.projectName.toLowerCase().includes(search.toLowerCase()) && 
        !run.id.toLowerCase().includes(search.toLowerCase()) &&
        !run.branch.toLowerCase().includes(search.toLowerCase())) {
      return false
    }
    if (statusFilter !== 'all' && run.status !== statusFilter) return false
    if (gateFilter !== 'all' && run.gate !== gateFilter) return false
    if (projectId && run.projectId !== projectId) return false
    return true
  }) || []

  return (
    <AppLayout title="Run History">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <div className="relative flex-1 min-w-[200px] max-w-[300px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search runs..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-input"
          />
        </div>

        <Select value={projectId} onValueChange={setProjectId}>
          <SelectTrigger className="w-[180px] bg-input">
            <SelectValue placeholder="All projects" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All projects</SelectItem>
            {projects?.map(p => (
              <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px] bg-input">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="running">Running</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>

        <Select value={gateFilter} onValueChange={setGateFilter}>
          <SelectTrigger className="w-[140px] bg-input">
            <SelectValue placeholder="Gate" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All gates</SelectItem>
            <SelectItem value="PASS">Pass</SelectItem>
            <SelectItem value="WARN">Warn</SelectItem>
            <SelectItem value="BLOCK">Block</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Results count */}
      <div className="mb-4">
        <p className="text-sm text-muted-foreground">
          {filteredRuns.length} runs found
        </p>
      </div>

      {/* Table */}
      {isLoading ? (
        <LoadingState message="Loading run history..." />
      ) : error ? (
        <ErrorState message="Failed to load run history" />
      ) : !filteredRuns.length ? (
        <EmptyState
          icon={<History className="w-6 h-6 text-muted-foreground" />}
          title="No runs found"
          description={search || statusFilter !== 'all' || gateFilter !== 'all'
            ? 'Try adjusting your filters'
            : 'Start a new run to see history here'
          }
        />
      ) : (
        <div className="border border-border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-card hover:bg-card">
                <TableHead className="w-[100px]">Run ID</TableHead>
                <TableHead>Project</TableHead>
                <TableHead>Branch</TableHead>
                <TableHead>Stages</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Gate</TableHead>
                <TableHead className="text-right">Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRuns.map((run, index) => (
                <TableRow
                  key={run.id}
                  className="cursor-pointer animate-slide-in"
                  style={{ animationDelay: `${index * 30}ms` }}
                >
                  <TableCell>
                    <Link 
                      href={run.status === 'running' ? '/live-console' : `/reports/${run.id}`}
                      className="font-mono text-xs text-muted-foreground hover:text-accent"
                    >
                      {run.id.slice(0, 8)}
                    </Link>
                  </TableCell>
                  <TableCell className="font-medium">{run.projectName}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                      <GitBranch className="w-3 h-3" />
                      {run.branch}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      {run.stages.slice(0, 3).map((stage, i) => (
                        <span
                          key={i}
                          className="text-xs px-1.5 py-0.5 rounded bg-secondary text-muted-foreground"
                        >
                          {stage.tool}
                        </span>
                      ))}
                      {run.stages.length > 3 && (
                        <span className="text-xs text-muted-foreground">
                          +{run.stages.length - 3}
                        </span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <RunStatusBadge status={run.status} />
                  </TableCell>
                  <TableCell>
                    {run.gate ? <GateBadge gate={run.gate} size="sm" /> : '-'}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="text-sm text-foreground">
                      {format(new Date(run.createdAt), 'MMM d, HH:mm')}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(run.createdAt), { addSuffix: true })}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </AppLayout>
  )
}

export default function HistoryPage() {
  return (
    <Suspense fallback={<AppLayout title="Run History"><LoadingState message="Loading..." /></AppLayout>}>
      <HistoryContent />
    </Suspense>
  )
}
