'use client'

import Link from 'next/link'
import { AppLayout } from '@/components/app-layout'
import { GateBadge, RunStatusBadge } from '@/components/badges'
import { LoadingState, EmptyState, ErrorState } from '@/components/states'
import { useRuns } from '@/lib/api'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Search, FileBarChart, GitBranch, Clock } from 'lucide-react'
import { useState } from 'react'
import { formatDistanceToNow } from 'date-fns'

export default function ReportsPage() {
  const { data: runs, isLoading, error } = useRuns()
  const [search, setSearch] = useState('')

  const completedRuns = runs?.filter(r => r.status === 'completed') || []
  const filteredRuns = completedRuns.filter(r =>
    r.projectName.toLowerCase().includes(search.toLowerCase()) ||
    r.id.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <AppLayout
      title="Reports"
      headerContent={
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search reports..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-64 pl-9 bg-input"
          />
        </div>
      }
    >
      <div className="mb-6">
        <p className="text-muted-foreground text-sm">
          {completedRuns.length} completed runs with reports
        </p>
      </div>

      {isLoading ? (
        <LoadingState message="Loading reports..." />
      ) : error ? (
        <ErrorState message="Failed to load reports" />
      ) : !filteredRuns.length ? (
        <EmptyState
          icon={<FileBarChart className="w-6 h-6 text-muted-foreground" />}
          title={search ? 'No reports found' : 'No reports yet'}
          description={search ? 'Try a different search term' : 'Complete a test run to see reports here'}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredRuns.map((run, index) => (
            <Link key={run.id} href={`/reports/${run.id}`}>
              <Card 
                className="bg-card border-border hover:border-accent/50 transition-all cursor-pointer animate-slide-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center">
                      <FileBarChart className="w-5 h-5 text-accent" />
                    </div>
                    {run.gate && <GateBadge gate={run.gate} size="sm" />}
                  </div>

                  <h3 className="text-base font-semibold text-foreground mb-1 truncate">
                    {run.projectName}
                  </h3>
                  
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
                    <GitBranch className="w-3 h-3" />
                    {run.branch}
                  </div>

                  <div className="flex items-center justify-between text-xs">
                    <code className="text-muted-foreground bg-secondary px-1.5 py-0.5 rounded font-mono">
                      {run.id.slice(0, 8)}
                    </code>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {formatDistanceToNow(new Date(run.createdAt), { addSuffix: true })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </AppLayout>
  )
}
