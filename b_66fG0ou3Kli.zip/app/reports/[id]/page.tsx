'use client'

import { use, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { AppLayout } from '@/components/app-layout'
import { ReportTabs } from '@/components/report-tabs'
import { ArtifactList } from '@/components/artifact-list'
import { RunMetaCard } from '@/components/run-meta-card'
import { LoadingState, ErrorState } from '@/components/states'
import { useRun, useReport, useArtifacts } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowLeft, Download, ExternalLink } from 'lucide-react'
import { cn } from '@/lib/utils'

function ReportDetailContent({ id }: { id: string }) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const initialTab = searchParams.get('tab') || 'summary'
  const [activeTab, setActiveTab] = useState(initialTab)

  const { data: run, isLoading: runLoading, error: runError } = useRun(id)
  const { data: report, isLoading: reportLoading, error: reportError } = useReport(id)
  const { data: artifacts } = useArtifacts(id)

  if (runLoading || reportLoading) {
    return (
      <AppLayout title="Report">
        <LoadingState message="Loading report..." />
      </AppLayout>
    )
  }

  if (runError || reportError || !run || !report) {
    return (
      <AppLayout title="Report">
        <ErrorState message="Failed to load report" />
      </AppLayout>
    )
  }

  const tabs = [
    { id: 'summary', label: 'Summary' },
    { id: 'functional', label: 'Functional', count: report.functional?.length },
    { id: 'performance', label: 'Performance', count: report.performance?.length },
    { id: 'security', label: 'Security', count: report.security?.length },
    { id: 'api', label: 'API', count: report.api?.length },
    { id: 'gate', label: 'Gate Trace', count: report.gateTrace?.length },
  ]

  return (
    <AppLayout title={`Report: ${run.projectName}`}>
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="ghost"
          className="gap-2"
          onClick={() => router.push('/reports')}
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Reports
        </Button>

        <div className="flex items-center gap-2">
          <Button variant="outline" className="gap-2">
            <ExternalLink className="w-4 h-4" />
            Open HTML
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Download
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-3 space-y-4">
          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-card border border-border w-full justify-start h-auto p-1 flex-wrap">
              {tabs.map((tab) => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className={cn(
                    'data-[state=active]:bg-accent data-[state=active]:text-accent-foreground',
                    'px-4 py-2 text-sm'
                  )}
                >
                  {tab.label}
                  {tab.count !== undefined && tab.count > 0 && (
                    <span className="ml-1.5 text-xs text-muted-foreground">
                      ({tab.count})
                    </span>
                  )}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>

          {/* Tab Content */}
          <ReportTabs report={report} activeTab={activeTab} />
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          <RunMetaCard run={run} />
          {artifacts && artifacts.length > 0 && (
            <ArtifactList artifacts={artifacts} />
          )}
        </div>
      </div>
    </AppLayout>
  )
}

export default function ReportDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  
  return (
    <Suspense fallback={<AppLayout title="Report"><LoadingState message="Loading..." /></AppLayout>}>
      <ReportDetailContent id={id} />
    </Suspense>
  )
}
