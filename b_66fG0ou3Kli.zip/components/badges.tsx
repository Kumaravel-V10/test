'use client'

import { cn } from '@/lib/utils'
import type { GateDecision, RunStatus, StageStatus } from '@/lib/types'
import { CheckCircle2, XCircle, AlertTriangle, Clock, Loader2, MinusCircle } from 'lucide-react'

// Gate Badge
interface GateBadgeProps {
  gate: GateDecision
  size?: 'sm' | 'md' | 'lg'
  className?: string
}

export function GateBadge({ gate, size = 'md', className }: GateBadgeProps) {
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-2.5 py-1',
    lg: 'text-base px-3 py-1.5',
  }

  const variants = {
    PASS: 'bg-status-pass/15 text-status-pass border-status-pass/30',
    WARN: 'bg-status-warn/15 text-status-warn border-status-warn/30',
    BLOCK: 'bg-status-block/15 text-status-block border-status-block/30',
  }

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 font-mono font-semibold rounded border',
        sizeClasses[size],
        variants[gate],
        className
      )}
    >
      {gate === 'PASS' && <CheckCircle2 className="w-3.5 h-3.5" />}
      {gate === 'WARN' && <AlertTriangle className="w-3.5 h-3.5" />}
      {gate === 'BLOCK' && <XCircle className="w-3.5 h-3.5" />}
      {gate}
    </span>
  )
}

// Run Status Badge
interface RunStatusBadgeProps {
  status: RunStatus
  className?: string
}

export function RunStatusBadge({ status, className }: RunStatusBadgeProps) {
  const variants: Record<RunStatus, string> = {
    pending: 'bg-status-pending/15 text-status-pending border-status-pending/30',
    running: 'bg-status-running/15 text-status-running border-status-running/30',
    completed: 'bg-status-pass/15 text-status-pass border-status-pass/30',
    failed: 'bg-status-block/15 text-status-block border-status-block/30',
    cancelled: 'bg-muted text-muted-foreground border-border',
  }

  const icons: Record<RunStatus, React.ReactNode> = {
    pending: <Clock className="w-3.5 h-3.5" />,
    running: <Loader2 className="w-3.5 h-3.5 animate-spin" />,
    completed: <CheckCircle2 className="w-3.5 h-3.5" />,
    failed: <XCircle className="w-3.5 h-3.5" />,
    cancelled: <MinusCircle className="w-3.5 h-3.5" />,
  }

  const labels: Record<RunStatus, string> = {
    pending: 'Pending',
    running: 'Running',
    completed: 'Completed',
    failed: 'Failed',
    cancelled: 'Cancelled',
  }

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 text-xs font-medium px-2 py-0.5 rounded border',
        variants[status],
        className
      )}
    >
      {icons[status]}
      {labels[status]}
    </span>
  )
}

// Stage Status Badge
interface StageStatusBadgeProps {
  status: StageStatus
  className?: string
}

export function StageStatusBadge({ status, className }: StageStatusBadgeProps) {
  const variants: Record<StageStatus, string> = {
    pending: 'bg-status-pending/15 text-status-pending',
    running: 'bg-status-running/15 text-status-running',
    passed: 'bg-status-pass/15 text-status-pass',
    failed: 'bg-status-block/15 text-status-block',
    skipped: 'bg-muted text-muted-foreground',
  }

  const icons: Record<StageStatus, React.ReactNode> = {
    pending: <Clock className="w-3 h-3" />,
    running: <Loader2 className="w-3 h-3 animate-spin" />,
    passed: <CheckCircle2 className="w-3 h-3" />,
    failed: <XCircle className="w-3 h-3" />,
    skipped: <MinusCircle className="w-3 h-3" />,
  }

  return (
    <span
      className={cn(
        'inline-flex items-center justify-center w-6 h-6 rounded-full',
        variants[status],
        className
      )}
    >
      {icons[status]}
    </span>
  )
}

// Severity Badge
interface SeverityBadgeProps {
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info'
  className?: string
}

export function SeverityBadge({ severity, className }: SeverityBadgeProps) {
  const variants = {
    critical: 'bg-red-500/15 text-red-400 border-red-500/30',
    high: 'bg-orange-500/15 text-orange-400 border-orange-500/30',
    medium: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
    low: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
    info: 'bg-gray-500/15 text-gray-400 border-gray-500/30',
  }

  return (
    <span
      className={cn(
        'inline-flex items-center text-xs font-medium px-2 py-0.5 rounded border uppercase',
        variants[severity],
        className
      )}
    >
      {severity}
    </span>
  )
}
