'use client'

import { useEffect, useRef } from 'react'
import { cn } from '@/lib/utils'
import type { LogEntry } from '@/lib/types'
import { format } from 'date-fns'

interface LogTerminalProps {
  logs: LogEntry[]
  autoScroll?: boolean
  className?: string
}

export function LogTerminal({ logs, autoScroll = true, className }: LogTerminalProps) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (autoScroll && containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight
    }
  }, [logs, autoScroll])

  return (
    <div
      ref={containerRef}
      className={cn(
        'bg-[#0a0a0a] rounded-lg border border-border overflow-auto font-mono text-sm',
        className
      )}
    >
      <div className="sticky top-0 flex items-center gap-2 px-4 py-2 bg-[#0a0a0a] border-b border-border">
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full bg-red-500/80" />
          <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
          <div className="w-3 h-3 rounded-full bg-green-500/80" />
        </div>
        <span className="text-xs text-muted-foreground ml-2">Run Console</span>
      </div>

      <div className="p-4 space-y-1">
        {logs.length === 0 ? (
          <div className="text-muted-foreground text-center py-8">
            Waiting for logs...
          </div>
        ) : (
          logs.map((log, index) => (
            <LogLine key={index} log={log} />
          ))
        )}
      </div>
    </div>
  )
}

interface LogLineProps {
  log: LogEntry
}

function LogLine({ log }: LogLineProps) {
  const levelColors = {
    info: 'text-blue-400',
    warn: 'text-yellow-400',
    error: 'text-red-400',
    debug: 'text-gray-500',
  }

  const levelLabels = {
    info: 'INFO ',
    warn: 'WARN ',
    error: 'ERROR',
    debug: 'DEBUG',
  }

  return (
    <div className="flex items-start gap-3 leading-relaxed hover:bg-white/5 -mx-2 px-2 rounded">
      <span className="text-muted-foreground shrink-0">
        {format(new Date(log.timestamp), 'HH:mm:ss')}
      </span>
      <span className={cn('shrink-0 font-semibold', levelColors[log.level])}>
        [{levelLabels[log.level]}]
      </span>
      {log.stage && (
        <span className="text-accent shrink-0">
          [{log.stage}]
        </span>
      )}
      <span className={cn(
        'flex-1',
        log.level === 'error' ? 'text-red-300' : 'text-foreground/90'
      )}>
        {log.message}
      </span>
    </div>
  )
}
