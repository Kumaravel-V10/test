'use client'

import { useUIStore } from '@/lib/stores'
import { cn } from '@/lib/utils'
import { AppSidebar } from './app-sidebar'
import { AppHeader } from './app-header'
import { Toaster } from './toaster'

interface AppLayoutProps {
  title?: string
  headerContent?: React.ReactNode
  children: React.ReactNode
}

export function AppLayout({ title, headerContent, children }: AppLayoutProps) {
  const { sidebarOpen } = useUIStore()

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />
      <AppHeader title={title}>{headerContent}</AppHeader>
      <main
        className={cn(
          'p-6 transition-all duration-300',
          sidebarOpen ? 'ml-60' : 'ml-16'
        )}
      >
        {children}
      </main>
      <Toaster />
    </div>
  )
}
