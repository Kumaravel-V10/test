'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import type { TestTool } from '@/lib/types'

interface ToolConfigPanelsProps {
  selectedTools: TestTool[]
  config: Record<string, Record<string, unknown>>
  onChange: (config: Record<string, Record<string, unknown>>) => void
}

export function ToolConfigPanels({ selectedTools, config, onChange }: ToolConfigPanelsProps) {
  const updateConfig = (tool: string, key: string, value: unknown) => {
    onChange({
      ...config,
      [tool]: {
        ...(config[tool] || {}),
        [key]: value,
      },
    })
  }

  if (selectedTools.length === 0) return null

  return (
    <div className="space-y-4">
      {selectedTools.includes('k6') && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">k6 Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="k6-vus" className="text-xs">Virtual Users (VUs)</Label>
                <Input
                  id="k6-vus"
                  type="number"
                  min={1}
                  max={1000}
                  value={config.k6?.vus as number || 10}
                  onChange={(e) => updateConfig('k6', 'vus', parseInt(e.target.value))}
                  className="bg-input"
                />
                <p className="text-xs text-muted-foreground">Number of concurrent users</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="k6-duration" className="text-xs">Duration</Label>
                <Input
                  id="k6-duration"
                  value={config.k6?.duration as string || '30s'}
                  onChange={(e) => updateConfig('k6', 'duration', e.target.value)}
                  placeholder="30s"
                  className="bg-input"
                />
                <p className="text-xs text-muted-foreground">e.g., 30s, 5m, 1h</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {selectedTools.includes('playwright') && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Playwright Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="pw-browser" className="text-xs">Browser</Label>
                <Select
                  value={config.playwright?.browser as string || 'chromium'}
                  onValueChange={(v) => updateConfig('playwright', 'browser', v)}
                >
                  <SelectTrigger id="pw-browser" className="bg-input">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="chromium">Chromium</SelectItem>
                    <SelectItem value="firefox">Firefox</SelectItem>
                    <SelectItem value="webkit">WebKit</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs">Headless Mode</Label>
                <div className="flex items-center gap-2 h-10">
                  <Switch
                    checked={config.playwright?.headless as boolean ?? true}
                    onCheckedChange={(c) => updateConfig('playwright', 'headless', c)}
                  />
                  <span className="text-sm text-muted-foreground">
                    {config.playwright?.headless !== false ? 'Enabled' : 'Disabled'}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {selectedTools.includes('zap') && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">ZAP Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="zap-mode" className="text-xs">Scan Mode</Label>
              <Select
                value={config.zap?.scanMode as string || 'baseline'}
                onValueChange={(v) => updateConfig('zap', 'scanMode', v)}
              >
                <SelectTrigger id="zap-mode" className="bg-input">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="baseline">Baseline (Fast)</SelectItem>
                  <SelectItem value="full">Full Scan</SelectItem>
                  <SelectItem value="api">API Scan</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">Baseline is recommended for CI pipelines</p>
            </div>
          </CardContent>
        </Card>
      )}

      {selectedTools.includes('newman') && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Newman Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="newman-iterations" className="text-xs">Iteration Count</Label>
              <Input
                id="newman-iterations"
                type="number"
                min={1}
                max={100}
                value={config.newman?.iterationCount as number || 1}
                onChange={(e) => updateConfig('newman', 'iterationCount', parseInt(e.target.value))}
                className="bg-input"
              />
              <p className="text-xs text-muted-foreground">Number of times to run the collection</p>
            </div>
          </CardContent>
        </Card>
      )}

      {selectedTools.includes('artillery') && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Artillery Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="artillery-duration" className="text-xs">Duration (seconds)</Label>
                <Input
                  id="artillery-duration"
                  type="number"
                  min={1}
                  max={3600}
                  value={config.artillery?.duration as number || 60}
                  onChange={(e) => updateConfig('artillery', 'duration', parseInt(e.target.value))}
                  className="bg-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="artillery-rate" className="text-xs">Arrival Rate</Label>
                <Input
                  id="artillery-rate"
                  type="number"
                  min={1}
                  max={100}
                  value={config.artillery?.arrivalRate as number || 5}
                  onChange={(e) => updateConfig('artillery', 'arrivalRate', parseInt(e.target.value))}
                  className="bg-input"
                />
                <p className="text-xs text-muted-foreground">Users per second</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {selectedTools.includes('lighthouse') && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Lighthouse Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label className="text-xs">Categories</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {['performance', 'accessibility', 'best-practices', 'seo'].map((cat) => {
                  const categories = (config.lighthouse?.categories as string[]) || ['performance', 'accessibility']
                  const isActive = categories.includes(cat)
                  
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => {
                        const newCats = isActive
                          ? categories.filter(c => c !== cat)
                          : [...categories, cat]
                        updateConfig('lighthouse', 'categories', newCats)
                      }}
                      className={`px-3 py-1 text-xs rounded-full transition-colors ${
                        isActive
                          ? 'bg-accent text-accent-foreground'
                          : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                      }`}
                    >
                      {cat}
                    </button>
                  )
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {selectedTools.includes('trivy') && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Trivy Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="trivy-severity" className="text-xs">Minimum Severity</Label>
              <Select
                value={config.trivy?.severity as string || 'HIGH,CRITICAL'}
                onValueChange={(v) => updateConfig('trivy', 'severity', v)}
              >
                <SelectTrigger id="trivy-severity" className="bg-input">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="CRITICAL">Critical Only</SelectItem>
                  <SelectItem value="HIGH,CRITICAL">High & Critical</SelectItem>
                  <SelectItem value="MEDIUM,HIGH,CRITICAL">Medium+</SelectItem>
                  <SelectItem value="LOW,MEDIUM,HIGH,CRITICAL">All</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      )}

      {selectedTools.includes('semgrep') && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Semgrep Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="semgrep-rules" className="text-xs">Rule Set</Label>
              <Select
                value={config.semgrep?.rules as string || 'auto'}
                onValueChange={(v) => updateConfig('semgrep', 'rules', v)}
              >
                <SelectTrigger id="semgrep-rules" className="bg-input">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">Auto-detect</SelectItem>
                  <SelectItem value="p/security-audit">Security Audit</SelectItem>
                  <SelectItem value="p/ci">CI Rules</SelectItem>
                  <SelectItem value="p/default">Default</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
