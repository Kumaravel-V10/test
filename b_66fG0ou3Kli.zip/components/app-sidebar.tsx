'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { useUIStore } from '@/lib/stores'
import {
  LayoutDashboard,
  FolderKanban,
  Play,
  Terminal,
  FileBarChart,
  History,
  Settings2,
  Cog,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'

const navItems = [
  { href: '/', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/projects', label: 'Projects', icon: FolderKanban },
  { href: '/new-run', label: 'New Run', icon: Play },
  { href: '/live-console', label: 'Live Console', icon: Terminal },
  { href: '/reports', label: 'Reports', icon: FileBarChart },
  { href: '/history', label: 'Run History', icon: History },
  { href: '/config', label: 'Test Config', icon: Settings2 },
  { href: '/settings', label: 'Settings', icon: Cog },
]

export function AppSidebar() {
  const pathname = usePathname()
  const { sidebarOpen, toggleSidebar } = useUIStore()

  return (
    <aside
      className={cn(
        'fixed left-0 top-0 z-40 h-screen bg-sidebar border-r border-sidebar-border transition-all duration-300',
        sidebarOpen ? 'w-60' : 'w-16'
      )}
    >
      {/* Logo */}
      <div className="flex items-center h-14 px-4 border-b border-sidebar-border">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
            <span className="font-bold text-accent-foreground text-sm">Q</span>
          </div>
          {sidebarOpen && (
            <span className="font-semibold text-sidebar-foreground tracking-tight">
              QUBE
            </span>
          )}
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-2 space-y-1">
        {navItems.map((item) => {
          const isActive = pathname === item.href || 
            (item.href !== '/' && pathname.startsWith(item.href))
          const Icon = item.icon

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                isActive
                  ? 'bg-sidebar-accent text-sidebar-primary'
                  : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground'
              )}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              {sidebarOpen && <span>{item.label}</span>}
            </Link>
          )
        })}
      </nav>

      {/* Toggle Button */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2">
        <Button
          variant="outline"
          size="icon"
          className="h-6 w-6 rounded-full bg-sidebar border-sidebar-border shadow-md"
          onClick={toggleSidebar}
        >
          {sidebarOpen ? (
            <ChevronLeft className="h-3 w-3" />
          ) : (
            <ChevronRight className="h-3 w-3" />
          )}
        </Button>
      </div>
    </aside>
  )
}
