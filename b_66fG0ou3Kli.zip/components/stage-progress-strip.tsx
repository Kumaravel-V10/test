'use client'

import { cn } from '@/lib/utils'
import { StageStatusBadge } from '@/components/badges'
import type { Stage } from '@/lib/types'
import { TOOLS } from '@/lib/types'

interface StageProgressStripProps {
  stages: Stage[]
  className?: string
}

export function StageProgressStrip({ stages, className }: StageProgressStripProps) {
  return (
    <div className={cn('flex items-center gap-2 overflow-x-auto py-2', className)}>
      {stages.map((stage, index) => {
        const tool = TOOLS.find(t => t.id === stage.tool)
        const isLast = index === stages.length - 1

        return (
          <div key={stage.name} className="flex items-center">
            <div
              className={cn(
                'flex items-center gap-2 px-3 py-2 rounded-lg transition-all',
                stage.status === 'running' && 'bg-status-running/10 ring-1 ring-status-running/30',
                stage.status === 'passed' && 'bg-status-pass/10',
                stage.status === 'failed' && 'bg-status-block/10',
                stage.status === 'pending' && 'bg-secondary',
                stage.status === 'skipped' && 'bg-muted'
              )}
            >
              <StageStatusBadge status={stage.status} />
              <span
                className={cn(
                  'text-sm font-medium whitespace-nowrap',
                  stage.status === 'running' && 'text-status-running',
                  stage.status === 'passed' && 'text-status-pass',
                  stage.status === 'failed' && 'text-status-block',
                  stage.status === 'pending' && 'text-muted-foreground',
                  stage.status === 'skipped' && 'text-muted-foreground'
                )}
              >
                {tool?.name || stage.name}
              </span>
              {stage.duration && (
                <span className="text-xs text-muted-foreground">
                  {formatDuration(stage.duration)}
                </span>
              )}
            </div>
            {!isLast && (
              <div
                className={cn(
                  'w-6 h-0.5 mx-1',
                  stages[index + 1]?.status === 'pending'
                    ? 'bg-border'
                    : 'bg-muted-foreground/30'
                )}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}

function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`
  const minutes = Math.floor(ms / 60000)
  const seconds = Math.floor((ms % 60000) / 1000)
  return `${minutes}m ${seconds}s`
}
