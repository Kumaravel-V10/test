'use client'

import { useState, useCallback, useRef } from 'react'
import { cn } from '@/lib/utils'
import { Upload, File, CheckCircle2, XCircle, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface ZipUploadProps {
  onUpload: (file: File) => Promise<void>
  disabled?: boolean
  className?: string
}

type UploadState = 'idle' | 'dragging' | 'uploading' | 'success' | 'error'

export function ZipUpload({ onUpload, disabled, className }: ZipUploadProps) {
  const [state, setState] = useState<UploadState>('idle')
  const [file, setFile] = useState<File | null>(null)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    if (!disabled) setState('dragging')
  }, [disabled])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setState('idle')
  }, [])

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault()
    if (disabled) return

    const droppedFile = e.dataTransfer.files[0]
    if (droppedFile && droppedFile.name.endsWith('.zip')) {
      await processFile(droppedFile)
    } else {
      setError('Please upload a ZIP file')
      setState('error')
    }
  }, [disabled])

  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      await processFile(selectedFile)
    }
  }, [])

  const processFile = async (file: File) => {
    setFile(file)
    setState('uploading')
    setError(null)
    setProgress(0)

    // Simulate progress
    const progressInterval = setInterval(() => {
      setProgress(prev => Math.min(prev + 10, 90))
    }, 100)

    try {
      await onUpload(file)
      clearInterval(progressInterval)
      setProgress(100)
      setState('success')
    } catch (err) {
      clearInterval(progressInterval)
      setError(err instanceof Error ? err.message : 'Upload failed')
      setState('error')
    }
  }

  const reset = () => {
    setState('idle')
    setFile(null)
    setProgress(0)
    setError(null)
    if (inputRef.current) inputRef.current.value = ''
  }

  return (
    <div
      className={cn(
        'relative rounded-lg border-2 border-dashed transition-all',
        state === 'idle' && 'border-border hover:border-muted-foreground/50',
        state === 'dragging' && 'border-accent bg-accent/5',
        state === 'uploading' && 'border-status-running bg-status-running/5',
        state === 'success' && 'border-status-pass bg-status-pass/5',
        state === 'error' && 'border-status-block bg-status-block/5',
        disabled && 'opacity-50 cursor-not-allowed',
        className
      )}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <input
        ref={inputRef}
        type="file"
        accept=".zip"
        onChange={handleFileSelect}
        className="hidden"
        disabled={disabled || state === 'uploading'}
      />

      <div className="p-8 flex flex-col items-center justify-center text-center">
        {state === 'idle' || state === 'dragging' ? (
          <>
            <div className={cn(
              'w-12 h-12 rounded-full flex items-center justify-center mb-4 transition-colors',
              state === 'dragging' ? 'bg-accent/20' : 'bg-muted'
            )}>
              <Upload className={cn(
                'w-6 h-6',
                state === 'dragging' ? 'text-accent' : 'text-muted-foreground'
              )} />
            </div>
            <p className="text-sm font-medium text-foreground mb-1">
              {state === 'dragging' ? 'Drop your ZIP file here' : 'Drag and drop your ZIP file'}
            </p>
            <p className="text-xs text-muted-foreground mb-4">
              or click to browse
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => inputRef.current?.click()}
              disabled={disabled}
            >
              Select File
            </Button>
          </>
        ) : state === 'uploading' ? (
          <>
            <Loader2 className="w-8 h-8 text-status-running animate-spin mb-4" />
            <p className="text-sm font-medium text-foreground mb-1">
              Uploading {file?.name}
            </p>
            <div className="w-48 h-2 bg-secondary rounded-full overflow-hidden mt-2">
              <div
                className="h-full bg-status-running transition-all duration-200"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">{progress}%</p>
          </>
        ) : state === 'success' ? (
          <>
            <div className="w-12 h-12 rounded-full bg-status-pass/20 flex items-center justify-center mb-4">
              <CheckCircle2 className="w-6 h-6 text-status-pass" />
            </div>
            <p className="text-sm font-medium text-foreground mb-1">
              Upload Complete
            </p>
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
              <File className="w-3 h-3" />
              {file?.name}
            </div>
            <Button variant="outline" size="sm" onClick={reset}>
              Upload Another
            </Button>
          </>
        ) : state === 'error' ? (
          <>
            <div className="w-12 h-12 rounded-full bg-status-block/20 flex items-center justify-center mb-4">
              <XCircle className="w-6 h-6 text-status-block" />
            </div>
            <p className="text-sm font-medium text-foreground mb-1">
              Upload Failed
            </p>
            <p className="text-xs text-status-block mb-4">{error}</p>
            <Button variant="outline" size="sm" onClick={reset}>
              Try Again
            </Button>
          </>
        ) : null}
      </div>
    </div>
  )
}
