'use client'

import { cn } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { GateBadge, SeverityBadge } from '@/components/badges'
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table'
import { CheckCircle2, XCircle, MinusCircle, AlertTriangle, ArrowRight, ArrowDown } from 'lucide-react'
import type { Report, FunctionalResult, PerformanceMetric, SecurityFinding, ApiResult, GateTrace } from '@/lib/types'

interface ReportTabsProps {
  report: Report
  activeTab: string
}

export function ReportTabs({ report, activeTab }: ReportTabsProps) {
  switch (activeTab) {
    case 'summary':
      return <SummaryTab report={report} />
    case 'functional':
      return <FunctionalTab results={report.functional || []} />
    case 'performance':
      return <PerformanceTab metrics={report.performance || []} />
    case 'security':
      return <SecurityTab findings={report.security || []} />
    case 'api':
      return <ApiTab results={report.api || []} />
    case 'gate':
      return <GateTab traces={report.gateTrace || []} summary={report.summary} />
    default:
      return <SummaryTab report={report} />
  }
}

// Summary Tab
function SummaryTab({ report }: { report: Report }) {
  const { summary } = report
  const passRate = summary.totalTests > 0 
    ? Math.round((summary.passed / summary.totalTests) * 100) 
    : 0

  return (
    <div className="space-y-6 animate-slide-in">
      {/* Gate Decision */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-foreground mb-1">Quality Gate</h3>
              <p className="text-sm text-muted-foreground">Overall run decision</p>
            </div>
            <GateBadge gate={summary.gate} size="lg" />
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Tests" value={summary.totalTests} />
        <StatCard label="Passed" value={summary.passed} variant="pass" />
        <StatCard label="Failed" value={summary.failed} variant="fail" />
        <StatCard label="Skipped" value={summary.skipped} variant="skip" />
      </div>

      {/* Pass Rate */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Pass Rate</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1 h-3 bg-secondary rounded-full overflow-hidden">
              <div
                className={cn(
                  'h-full transition-all',
                  passRate >= 95 ? 'bg-status-pass' : passRate >= 80 ? 'bg-status-warn' : 'bg-status-block'
                )}
                style={{ width: `${passRate}%` }}
              />
            </div>
            <span className={cn(
              'text-xl font-bold',
              passRate >= 95 ? 'text-status-pass' : passRate >= 80 ? 'text-status-warn' : 'text-status-block'
            )}>
              {passRate}%
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Duration */}
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Total Duration</span>
            <span className="text-sm font-medium text-foreground">
              {formatDuration(summary.duration)}
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Functional Tab
function FunctionalTab({ results }: { results: FunctionalResult[] }) {
  const grouped = results.reduce((acc, r) => {
    if (!acc[r.suite]) acc[r.suite] = []
    acc[r.suite].push(r)
    return acc
  }, {} as Record<string, FunctionalResult[]>)

  return (
    <div className="space-y-4 animate-slide-in">
      {Object.entries(grouped).map(([suite, tests]) => (
        <Card key={suite} className="bg-card border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">{suite}</CardTitle>
              <Badge variant="outline" className="text-xs">
                {tests.filter(t => t.status === 'passed').length}/{tests.length} passed
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">Status</TableHead>
                  <TableHead>Test</TableHead>
                  <TableHead className="w-24 text-right">Duration</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tests.map((test, i) => (
                  <TableRow key={i}>
                    <TableCell>
                      {test.status === 'passed' && <CheckCircle2 className="w-4 h-4 text-status-pass" />}
                      {test.status === 'failed' && <XCircle className="w-4 h-4 text-status-block" />}
                      {test.status === 'skipped' && <MinusCircle className="w-4 h-4 text-muted-foreground" />}
                    </TableCell>
                    <TableCell>
                      <div>
                        <span className="text-sm text-foreground">{test.test}</span>
                        {test.error && (
                          <p className="text-xs text-status-block mt-1">{test.error}</p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right text-xs text-muted-foreground">
                      {test.duration}ms
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

// Performance Tab
function PerformanceTab({ metrics }: { metrics: PerformanceMetric[] }) {
  return (
    <div className="space-y-4 animate-slide-in">
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Performance Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Metric</TableHead>
                <TableHead className="text-right">Value</TableHead>
                <TableHead className="text-right">Threshold</TableHead>
                <TableHead className="w-20 text-center">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {metrics.map((metric, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">{metric.name}</TableCell>
                  <TableCell className="text-right">
                    {metric.value}{metric.unit}
                  </TableCell>
                  <TableCell className="text-right text-muted-foreground">
                    {metric.threshold ? `${metric.threshold}${metric.unit}` : '-'}
                  </TableCell>
                  <TableCell className="text-center">
                    {metric.status === 'pass' && <CheckCircle2 className="w-4 h-4 text-status-pass mx-auto" />}
                    {metric.status === 'warn' && <AlertTriangle className="w-4 h-4 text-status-warn mx-auto" />}
                    {metric.status === 'fail' && <XCircle className="w-4 h-4 text-status-block mx-auto" />}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// Security Tab
function SecurityTab({ findings }: { findings: SecurityFinding[] }) {
  const grouped = {
    critical: findings.filter(f => f.severity === 'critical'),
    high: findings.filter(f => f.severity === 'high'),
    medium: findings.filter(f => f.severity === 'medium'),
    low: findings.filter(f => f.severity === 'low'),
    info: findings.filter(f => f.severity === 'info'),
  }

  return (
    <div className="space-y-4 animate-slide-in">
      {/* Summary */}
      <div className="grid grid-cols-5 gap-2">
        {Object.entries(grouped).map(([severity, items]) => (
          <Card key={severity} className="bg-card border-border">
            <CardContent className="p-3 text-center">
              <span className="text-2xl font-bold text-foreground">{items.length}</span>
              <p className="text-xs text-muted-foreground capitalize">{severity}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Findings */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Security Findings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {findings.map((finding) => (
              <div
                key={finding.id}
                className="p-3 rounded-lg bg-secondary/50"
              >
                <div className="flex items-start justify-between mb-2">
                  <span className="text-sm font-medium text-foreground">{finding.title}</span>
                  <SeverityBadge severity={finding.severity} />
                </div>
                <p className="text-xs text-muted-foreground mb-2">{finding.description}</p>
                {finding.recommendation && (
                  <p className="text-xs text-accent">{finding.recommendation}</p>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// API Tab
function ApiTab({ results }: { results: ApiResult[] }) {
  return (
    <div className="space-y-4 animate-slide-in">
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">API Test Results</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Endpoint</TableHead>
                <TableHead className="w-20">Method</TableHead>
                <TableHead className="w-20">Status</TableHead>
                <TableHead className="w-24 text-right">Duration</TableHead>
                <TableHead className="w-24 text-right">Assertions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {results.map((result, i) => (
                <TableRow key={i}>
                  <TableCell className="font-mono text-sm">{result.endpoint}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-xs">{result.method}</Badge>
                  </TableCell>
                  <TableCell>
                    <span className={cn(
                      'text-sm font-medium',
                      result.status < 300 ? 'text-status-pass' : 'text-status-block'
                    )}>
                      {result.status}
                    </span>
                  </TableCell>
                  <TableCell className="text-right text-xs text-muted-foreground">
                    {result.duration}ms
                  </TableCell>
                  <TableCell className="text-right">
                    <span className={cn(
                      'text-xs',
                      result.assertions.every(a => a.passed) ? 'text-status-pass' : 'text-status-block'
                    )}>
                      {result.assertions.filter(a => a.passed).length}/{result.assertions.length}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// Gate Tab
function GateTab({ traces, summary }: { traces: GateTrace[]; summary: Report['summary'] }) {
  return (
    <div className="space-y-4 animate-slide-in">
      {/* Final Decision */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <div className="flex items-center justify-center gap-4">
            <span className="text-lg text-muted-foreground">Final Decision</span>
            <ArrowRight className="w-5 h-5 text-muted-foreground" />
            <GateBadge gate={summary.gate} size="lg" />
          </div>
        </CardContent>
      </Card>

      {/* Gate Trace */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Gate Trace</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Rule</TableHead>
                <TableHead>Metric</TableHead>
                <TableHead className="text-right">Threshold</TableHead>
                <TableHead className="text-right">Actual</TableHead>
                <TableHead className="w-20 text-center">Result</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {traces.map((trace, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">{trace.rule}</TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">{trace.metric}</TableCell>
                  <TableCell className="text-right">{trace.threshold}</TableCell>
                  <TableCell className="text-right">{trace.actual}</TableCell>
                  <TableCell className="text-center">
                    {trace.result === 'pass' ? (
                      <CheckCircle2 className="w-4 h-4 text-status-pass mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-status-block mx-auto" />
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

// Helper Components
function StatCard({ label, value, variant }: { label: string; value: number; variant?: 'pass' | 'fail' | 'skip' }) {
  const colors = {
    pass: 'text-status-pass',
    fail: 'text-status-block',
    skip: 'text-muted-foreground',
  }

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4 text-center">
        <span className={cn('text-3xl font-bold', variant ? colors[variant] : 'text-foreground')}>
          {value}
        </span>
        <p className="text-xs text-muted-foreground mt-1">{label}</p>
      </CardContent>
    </Card>
  )
}

function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`
  const minutes = Math.floor(ms / 60000)
  const seconds = Math.floor((ms % 60000) / 1000)
  return `${minutes}m ${seconds}s`
}
