'use client'

import { useEffect } from 'react'
import { useUIStore } from '@/lib/stores'
import { cn } from '@/lib/utils'
import { X, CheckCircle2, AlertCircle, Info } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function Toaster() {
  const { toasts, removeToast } = useUIStore()

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          id={toast.id}
          message={toast.message}
          type={toast.type}
          onClose={() => removeToast(toast.id)}
        />
      ))}
    </div>
  )
}

interface ToastProps {
  id: string
  message: string
  type: 'success' | 'error' | 'info'
  onClose: () => void
}

function Toast({ id, message, type, onClose }: ToastProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose()
    }, 5000)
    return () => clearTimeout(timer)
  }, [id, onClose])

  const icons = {
    success: <CheckCircle2 className="w-4 h-4 text-status-pass" />,
    error: <AlertCircle className="w-4 h-4 text-status-block" />,
    info: <Info className="w-4 h-4 text-status-running" />,
  }

  const variants = {
    success: 'border-status-pass/30',
    error: 'border-status-block/30',
    info: 'border-status-running/30',
  }

  return (
    <div
      className={cn(
        'flex items-center gap-3 px-4 py-3 bg-card border rounded-lg shadow-lg animate-slide-in min-w-[300px]',
        variants[type]
      )}
    >
      {icons[type]}
      <p className="text-sm text-foreground flex-1">{message}</p>
      <Button
        variant="ghost"
        size="icon"
        className="h-6 w-6"
        onClick={onClose}
      >
        <X className="w-3 h-3" />
      </Button>
    </div>
  )
}
