'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { FileText, FileJson, FileCode, File, Download, ExternalLink } from 'lucide-react'
import type { Artifact } from '@/lib/types'

interface ArtifactListProps {
  artifacts: Artifact[]
}

export function ArtifactList({ artifacts }: ArtifactListProps) {
  const getIcon = (type: Artifact['type']) => {
    switch (type) {
      case 'html':
        return <FileText className="w-4 h-4 text-orange-400" />
      case 'json':
        return <FileJson className="w-4 h-4 text-yellow-400" />
      case 'log':
        return <FileCode className="w-4 h-4 text-blue-400" />
      default:
        return <File className="w-4 h-4 text-muted-foreground" />
    }
  }

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Artifacts</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {artifacts.map((artifact) => (
            <div
              key={artifact.id}
              className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <div className="flex items-center gap-3 min-w-0">
                {getIcon(artifact.type)}
                <div className="min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {artifact.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatSize(artifact.size)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {artifact.type === 'html' && (
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                )}
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
