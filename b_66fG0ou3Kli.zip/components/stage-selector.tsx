'use client'

import { cn } from '@/lib/utils'
import { TOOLS, type TestTool, type ToolInfo } from '@/lib/types'
import { Check, Zap, FlaskConical, Shield, Globe } from 'lucide-react'

interface StageSelectorProps {
  selected: TestTool[]
  onChange: (tools: TestTool[]) => void
  localMode?: boolean
  className?: string
}

const categoryIcons = {
  performance: Zap,
  functional: FlaskConical,
  security: Shield,
  api: Globe,
}

const categoryColors = {
  performance: 'text-chart-1',
  functional: 'text-chart-2',
  security: 'text-chart-4',
  api: 'text-chart-5',
}

export function StageSelector({ selected, onChange, localMode, className }: StageSelectorProps) {
  const toggleTool = (tool: TestTool) => {
    if (selected.includes(tool)) {
      onChange(selected.filter(t => t !== tool))
    } else {
      onChange([...selected, tool])
    }
  }

  const groupedTools = TOOLS.reduce((acc, tool) => {
    if (!acc[tool.category]) acc[tool.category] = []
    acc[tool.category].push(tool)
    return acc
  }, {} as Record<string, ToolInfo[]>)

  const hasNonLocalTools = selected.some(t => {
    const tool = TOOLS.find(ti => ti.id === t)
    return tool && !tool.localModeSupported
  })

  return (
    <div className={className}>
      <div className="space-y-6">
        {Object.entries(groupedTools).map(([category, tools]) => {
          const CategoryIcon = categoryIcons[category as keyof typeof categoryIcons]
          const colorClass = categoryColors[category as keyof typeof categoryColors]

          return (
            <div key={category}>
              <div className="flex items-center gap-2 mb-3">
                <CategoryIcon className={cn('w-4 h-4', colorClass)} />
                <h4 className="text-sm font-medium text-foreground capitalize">
                  {category}
                </h4>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {tools.map((tool) => {
                  const isSelected = selected.includes(tool.id)
                  const isDisabled = localMode && !tool.localModeSupported

                  return (
                    <button
                      key={tool.id}
                      type="button"
                      onClick={() => !isDisabled && toggleTool(tool.id)}
                      disabled={isDisabled}
                      className={cn(
                        'relative flex flex-col items-start p-4 rounded-lg border-2 transition-all text-left',
                        isSelected
                          ? 'border-accent bg-accent/10'
                          : 'border-border hover:border-muted-foreground/50',
                        isDisabled && 'opacity-50 cursor-not-allowed'
                      )}
                    >
                      {isSelected && (
                        <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-accent flex items-center justify-center">
                          <Check className="w-3 h-3 text-accent-foreground" />
                        </div>
                      )}
                      <span className="text-sm font-medium text-foreground mb-1">
                        {tool.name}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {tool.description}
                      </span>
                      {localMode && !tool.localModeSupported && (
                        <span className="text-xs text-status-warn mt-2">
                          Requires full stack
                        </span>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>

      {/* Warning for non-local tools */}
      {localMode && hasNonLocalTools && (
        <div className="mt-6 p-4 rounded-lg bg-status-warn/10 border border-status-warn/30">
          <p className="text-sm text-status-warn">
            Selected engine needs full worker stack in non-local mode.
          </p>
        </div>
      )}

      {/* Selected tools summary */}
      {selected.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-2">
          {selected.map((toolId) => {
            const tool = TOOLS.find(t => t.id === toolId)
            if (!tool) return null
            
            return (
              <span
                key={toolId}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-accent/15 text-accent text-sm"
              >
                {tool.name}
                <button
                  type="button"
                  onClick={() => toggleTool(toolId)}
                  className="hover:text-accent-foreground"
                >
                  ×
                </button>
              </span>
            )
          })}
        </div>
      )}
    </div>
  )
}
