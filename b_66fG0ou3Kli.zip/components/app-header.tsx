'use client'

import { useUIStore, useSettingsStore, useAuthStore } from '@/lib/stores'
import { cn } from '@/lib/utils'
import { User, Wifi, WifiOff } from 'lucide-react'
import { Badge } from '@/components/ui/badge'

interface AppHeaderProps {
  title?: string
  children?: React.ReactNode
}

export function AppHeader({ title, children }: AppHeaderProps) {
  const { sidebarOpen } = useUIStore()
  const { localMode } = useSettingsStore()
  const { isGuest } = useAuthStore()

  return (
    <header
      className={cn(
        'sticky top-0 z-30 h-14 bg-background/80 backdrop-blur-sm border-b border-border flex items-center justify-between px-6 transition-all duration-300',
        sidebarOpen ? 'ml-60' : 'ml-16'
      )}
    >
      <div className="flex items-center gap-4">
        {title && <h1 className="text-lg font-semibold text-foreground">{title}</h1>}
        {children}
      </div>

      <div className="flex items-center gap-3">
        {/* Local Mode Indicator */}
        <Badge
          variant="outline"
          className={cn(
            'flex items-center gap-1.5 text-xs',
            localMode
              ? 'border-status-pass/30 text-status-pass'
              : 'border-status-warn/30 text-status-warn'
          )}
        >
          {localMode ? (
            <>
              <Wifi className="w-3 h-3" />
              Local Mode
            </>
          ) : (
            <>
              <WifiOff className="w-3 h-3" />
              Remote
            </>
          )}
        </Badge>

        {/* Guest Indicator */}
        {isGuest && (
          <Badge variant="secondary" className="flex items-center gap-1.5 text-xs">
            <User className="w-3 h-3" />
            Guest
          </Badge>
        )}
      </div>
    </header>
  )
}
