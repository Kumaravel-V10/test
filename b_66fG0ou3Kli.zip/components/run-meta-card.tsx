'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { GateBadge, RunStatusBadge } from '@/components/badges'
import { GitBranch, Clock, Timer, Layers } from 'lucide-react'
import { format, formatDistanceToNow } from 'date-fns'
import type { Run } from '@/lib/types'

interface RunMetaCardProps {
  run: Run
}

export function RunMetaCard({ run }: RunMetaCardProps) {
  const formatDuration = (ms: number) => {
    if (ms < 1000) return `${ms}ms`
    if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`
    const minutes = Math.floor(ms / 60000)
    const seconds = Math.floor((ms % 60000) / 1000)
    return `${minutes}m ${seconds}s`
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Run Details</CardTitle>
          <RunStatusBadge status={run.status} />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Gate Decision */}
        {run.gate && (
          <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
            <span className="text-sm text-muted-foreground">Gate Decision</span>
            <GateBadge gate={run.gate} size="md" />
          </div>
        )}

        {/* Metadata */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <GitBranch className="w-4 h-4" />
              Branch
            </div>
            <span className="text-sm font-medium text-foreground">{run.branch}</span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Layers className="w-4 h-4" />
              Stages
            </div>
            <span className="text-sm font-medium text-foreground">
              {run.stages.length}
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="w-4 h-4" />
              Started
            </div>
            <span className="text-sm text-foreground">
              {run.startedAt
                ? format(new Date(run.startedAt), 'HH:mm:ss')
                : '-'}
            </span>
          </div>

          {run.duration && (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Timer className="w-4 h-4" />
                Duration
              </div>
              <span className="text-sm font-medium text-foreground">
                {formatDuration(run.duration)}
              </span>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              Project
            </div>
            <span className="text-sm text-foreground">
              {run.projectName}
            </span>
          </div>
        </div>

        {/* Run ID */}
        <div className="pt-3 border-t border-border">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Run ID</span>
            <code className="text-xs font-mono text-muted-foreground bg-secondary px-2 py-1 rounded">
              {run.id}
            </code>
          </div>
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-muted-foreground">Created</span>
            <span className="text-xs text-muted-foreground">
              {formatDistanceToNow(new Date(run.createdAt), { addSuffix: true })}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
