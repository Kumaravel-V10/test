'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Run, LogEntry, AppSettings, ToolConfig, TestTool } from './types'

// Auth Store (Guest mode only for now)
interface AuthState {
  isGuest: boolean
  user: null
}

export const useAuthStore = create<AuthState>()(() => ({
  isGuest: true,
  user: null,
}))

// Run Store
interface RunState {
  currentRun: Run | null
  logs: LogEntry[]
  isLive: boolean
  setCurrentRun: (run: Run | null) => void
  addLog: (log: LogEntry) => void
  clearLogs: () => void
  setLive: (live: boolean) => void
  updateStageStatus: (stageName: string, status: Run['stages'][0]['status']) => void
}

export const useRunStore = create<RunState>((set) => ({
  currentRun: null,
  logs: [],
  isLive: false,
  setCurrentRun: (run) => set({ currentRun: run }),
  addLog: (log) => set((state) => ({ logs: [...state.logs, log] })),
  clearLogs: () => set({ logs: [] }),
  setLive: (live) => set({ isLive: live }),
  updateStageStatus: (stageName, status) =>
    set((state) => {
      if (!state.currentRun) return state
      return {
        currentRun: {
          ...state.currentRun,
          stages: state.currentRun.stages.map((s) =>
            s.name === stageName ? { ...s, status } : s
          ),
        },
      }
    }),
}))

// UI Store
interface UIState {
  sidebarOpen: boolean
  activeModal: string | null
  toasts: { id: string; message: string; type: 'success' | 'error' | 'info' }[]
  toggleSidebar: () => void
  setSidebarOpen: (open: boolean) => void
  openModal: (modalId: string) => void
  closeModal: () => void
  addToast: (message: string, type: 'success' | 'error' | 'info') => void
  removeToast: (id: string) => void
}

export const useUIStore = create<UIState>((set) => ({
  sidebarOpen: true,
  activeModal: null,
  toasts: [],
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  openModal: (modalId) => set({ activeModal: modalId }),
  closeModal: () => set({ activeModal: null }),
  addToast: (message, type) =>
    set((state) => ({
      toasts: [...state.toasts, { id: Date.now().toString(), message, type }],
    })),
  removeToast: (id) =>
    set((state) => ({
      toasts: state.toasts.filter((t) => t.id !== id),
    })),
}))

// Settings Store (persisted)
interface SettingsState extends AppSettings {
  toolConfigs: ToolConfig[]
  updateSettings: (settings: Partial<AppSettings>) => void
  updateToolConfig: (tool: TestTool, config: Partial<ToolConfig>) => void
}

const defaultToolConfigs: ToolConfig[] = [
  { tool: 'k6', enabled: true, config: { vus: 10, duration: '30s' } },
  { tool: 'playwright', enabled: false, config: { browser: 'chromium', headless: true } },
  { tool: 'zap', enabled: false, config: { scanMode: 'baseline' } },
  { tool: 'newman', enabled: false, config: { iterationCount: 1 } },
  { tool: 'artillery', enabled: false, config: { duration: 60, arrivalRate: 5 } },
  { tool: 'lighthouse', enabled: false, config: { categories: ['performance', 'accessibility'] } },
  { tool: 'trivy', enabled: false, config: { severity: 'HIGH,CRITICAL' } },
  { tool: 'semgrep', enabled: false, config: { rules: 'auto' } },
]

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      localMode: true,
      apiBaseUrl: 'http://localhost:8080',
      runtimeNotes: '',
      toolConfigs: defaultToolConfigs,
      updateSettings: (settings) => set((state) => ({ ...state, ...settings })),
      updateToolConfig: (tool, config) =>
        set((state) => ({
          toolConfigs: state.toolConfigs.map((tc) =>
            tc.tool === tool ? { ...tc, ...config } : tc
          ),
        })),
    }),
    {
      name: 'qube-settings',
    }
  )
)
