import type { Project, Run, Report, Artifact, LogEntry } from './types'

export const mockProjects: Project[] = [
  {
    id: 'proj-1',
    name: 'ecommerce-api',
    sourceType: 'github',
    repoUrl: 'https://github.com/acme/ecommerce-api',
    branch: 'main',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-03-10T14:30:00Z',
    lastRunAt: '2024-03-10T14:30:00Z',
    latestGate: 'PASS',
  },
  {
    id: 'proj-2',
    name: 'payment-service',
    sourceType: 'zip',
    branch: 'uploaded',
    createdAt: '2024-02-20T09:00:00Z',
    updatedAt: '2024-03-09T11:00:00Z',
    lastRunAt: '2024-03-09T11:00:00Z',
    latestGate: 'WARN',
  },
  {
    id: 'proj-3',
    name: 'auth-gateway',
    sourceType: 'github',
    repoUrl: 'https://github.com/acme/auth-gateway',
    branch: 'develop',
    createdAt: '2024-01-05T08:00:00Z',
    updatedAt: '2024-03-08T16:45:00Z',
    lastRunAt: '2024-03-08T16:45:00Z',
    latestGate: 'BLOCK',
  },
  {
    id: 'proj-4',
    name: 'frontend-app',
    sourceType: 'github',
    repoUrl: 'https://github.com/acme/frontend-app',
    branch: 'main',
    createdAt: '2024-03-01T12:00:00Z',
    updatedAt: '2024-03-07T10:00:00Z',
  },
]

export const mockRuns: Run[] = [
  {
    id: 'run-1',
    projectId: 'proj-1',
    projectName: 'ecommerce-api',
    branch: 'main',
    status: 'completed',
    gate: 'PASS',
    selectedTools: ['k6', 'newman', 'trivy'],
    stages: [
      { name: 'k6', tool: 'k6', status: 'passed', duration: 45000 },
      { name: 'newman', tool: 'newman', status: 'passed', duration: 12000 },
      { name: 'trivy', tool: 'trivy', status: 'passed', duration: 8000 },
    ],
    createdAt: '2024-03-10T14:00:00Z',
    startedAt: '2024-03-10T14:00:05Z',
    completedAt: '2024-03-10T14:30:00Z',
    duration: 1795000,
  },
  {
    id: 'run-2',
    projectId: 'proj-2',
    projectName: 'payment-service',
    branch: 'uploaded',
    status: 'completed',
    gate: 'WARN',
    selectedTools: ['k6', 'zap', 'semgrep'],
    stages: [
      { name: 'k6', tool: 'k6', status: 'passed', duration: 60000 },
      { name: 'zap', tool: 'zap', status: 'passed', duration: 120000 },
      { name: 'semgrep', tool: 'semgrep', status: 'failed', duration: 15000 },
    ],
    createdAt: '2024-03-09T10:30:00Z',
    startedAt: '2024-03-09T10:30:10Z',
    completedAt: '2024-03-09T11:00:00Z',
    duration: 1790000,
  },
  {
    id: 'run-3',
    projectId: 'proj-3',
    projectName: 'auth-gateway',
    branch: 'develop',
    status: 'completed',
    gate: 'BLOCK',
    selectedTools: ['playwright', 'trivy', 'lighthouse'],
    stages: [
      { name: 'playwright', tool: 'playwright', status: 'failed', duration: 90000, error: 'Assertion failed' },
      { name: 'trivy', tool: 'trivy', status: 'failed', duration: 10000, error: 'Critical vulnerabilities found' },
      { name: 'lighthouse', tool: 'lighthouse', status: 'passed', duration: 25000 },
    ],
    createdAt: '2024-03-08T16:00:00Z',
    startedAt: '2024-03-08T16:00:15Z',
    completedAt: '2024-03-08T16:45:00Z',
    duration: 2685000,
  },
  {
    id: 'run-4',
    projectId: 'proj-1',
    projectName: 'ecommerce-api',
    branch: 'feature/checkout',
    status: 'running',
    selectedTools: ['k6', 'playwright'],
    stages: [
      { name: 'k6', tool: 'k6', status: 'passed', duration: 45000 },
      { name: 'playwright', tool: 'playwright', status: 'running' },
    ],
    createdAt: '2024-03-10T15:00:00Z',
    startedAt: '2024-03-10T15:00:05Z',
  },
]

export const mockReport: Report = {
  runId: 'run-1',
  summary: {
    totalTests: 156,
    passed: 152,
    failed: 2,
    skipped: 2,
    duration: 1795000,
    gate: 'PASS',
  },
  functional: [
    { suite: 'Auth', test: 'Login with valid credentials', status: 'passed', duration: 1200 },
    { suite: 'Auth', test: 'Login with invalid password', status: 'passed', duration: 800 },
    { suite: 'Cart', test: 'Add item to cart', status: 'passed', duration: 1500 },
    { suite: 'Cart', test: 'Remove item from cart', status: 'passed', duration: 1100 },
    { suite: 'Checkout', test: 'Complete purchase', status: 'failed', duration: 3200, error: 'Payment gateway timeout' },
    { suite: 'Checkout', test: 'Apply discount code', status: 'passed', duration: 900 },
  ],
  performance: [
    { name: 'Response Time (p95)', value: 245, unit: 'ms', threshold: 500, status: 'pass' },
    { name: 'Response Time (p99)', value: 480, unit: 'ms', threshold: 500, status: 'warn' },
    { name: 'Throughput', value: 1250, unit: 'req/s', threshold: 1000, status: 'pass' },
    { name: 'Error Rate', value: 0.02, unit: '%', threshold: 1, status: 'pass' },
    { name: 'Virtual Users', value: 100, unit: 'VUs', status: 'pass' },
  ],
  security: [
    { id: 'sec-1', severity: 'medium', title: 'Missing Content-Security-Policy', description: 'CSP header not set', recommendation: 'Add Content-Security-Policy header' },
    { id: 'sec-2', severity: 'low', title: 'Cookie without SameSite', description: 'Session cookie missing SameSite attribute', recommendation: 'Set SameSite=Strict' },
    { id: 'sec-3', severity: 'info', title: 'X-Powered-By header present', description: 'Server technology disclosed', recommendation: 'Remove X-Powered-By header' },
  ],
  api: [
    { endpoint: '/api/v1/products', method: 'GET', status: 200, duration: 45, assertions: [{ name: 'Status is 200', passed: true }, { name: 'Response time < 100ms', passed: true }] },
    { endpoint: '/api/v1/cart', method: 'POST', status: 201, duration: 78, assertions: [{ name: 'Status is 201', passed: true }, { name: 'Has cart ID', passed: true }] },
    { endpoint: '/api/v1/checkout', method: 'POST', status: 200, duration: 156, assertions: [{ name: 'Status is 200', passed: true }, { name: 'Has order ID', passed: true }] },
  ],
  gateTrace: [
    { rule: 'Performance', metric: 'p95_response_time', threshold: 500, actual: 245, result: 'pass' },
    { rule: 'Performance', metric: 'error_rate', threshold: 1, actual: 0.02, result: 'pass' },
    { rule: 'Security', metric: 'critical_vulnerabilities', threshold: 0, actual: 0, result: 'pass' },
    { rule: 'Functional', metric: 'test_pass_rate', threshold: 95, actual: 97.4, result: 'pass' },
  ],
}

export const mockArtifacts: Artifact[] = [
  { id: 'art-1', name: 'merged-report.html', type: 'html', size: 245000, downloadUrl: '/artifacts/merged-report.html' },
  { id: 'art-2', name: 'gate-report.json', type: 'json', size: 12000, downloadUrl: '/artifacts/gate-report.json' },
  { id: 'art-3', name: 'k6-results.json', type: 'json', size: 89000, downloadUrl: '/artifacts/k6-results.json' },
  { id: 'art-4', name: 'playwright-trace.zip', type: 'other', size: 1500000, downloadUrl: '/artifacts/playwright-trace.zip' },
  { id: 'art-5', name: 'run.log', type: 'log', size: 34000, downloadUrl: '/artifacts/run.log' },
]

export const mockLogs: LogEntry[] = [
  { timestamp: '2024-03-10T15:00:05Z', level: 'info', message: 'Starting test run...' },
  { timestamp: '2024-03-10T15:00:06Z', level: 'info', stage: 'k6', message: 'Initializing k6 load test' },
  { timestamp: '2024-03-10T15:00:07Z', level: 'info', stage: 'k6', message: 'Running with 10 VUs for 30s' },
  { timestamp: '2024-03-10T15:00:15Z', level: 'debug', stage: 'k6', message: 'VU 1: GET /api/products - 200 (45ms)' },
  { timestamp: '2024-03-10T15:00:16Z', level: 'debug', stage: 'k6', message: 'VU 2: POST /api/cart - 201 (78ms)' },
  { timestamp: '2024-03-10T15:00:20Z', level: 'warn', stage: 'k6', message: 'Response time spike detected: 450ms' },
  { timestamp: '2024-03-10T15:00:37Z', level: 'info', stage: 'k6', message: 'k6 completed - PASS' },
  { timestamp: '2024-03-10T15:00:38Z', level: 'info', stage: 'playwright', message: 'Starting Playwright tests' },
  { timestamp: '2024-03-10T15:00:40Z', level: 'info', stage: 'playwright', message: 'Launching Chromium browser' },
  { timestamp: '2024-03-10T15:00:45Z', level: 'info', stage: 'playwright', message: 'Running test: Login flow' },
  { timestamp: '2024-03-10T15:00:50Z', level: 'error', stage: 'playwright', message: 'Test failed: Expected button to be visible' },
]

export function generateMockLogs(): LogEntry[] {
  const stages = ['k6', 'playwright', 'zap', 'newman']
  const levels: LogEntry['level'][] = ['info', 'debug', 'warn', 'error']
  const messages = [
    'Initializing stage...',
    'Running test suite',
    'Processing results',
    'Completed successfully',
    'Warning: threshold approaching limit',
    'Error: connection timeout',
    'Retrying request...',
    'Test passed',
    'Test failed',
    'Collecting metrics',
  ]

  return Array.from({ length: 50 }, (_, i) => ({
    timestamp: new Date(Date.now() - (50 - i) * 1000).toISOString(),
    level: levels[Math.floor(Math.random() * levels.length)],
    stage: stages[Math.floor(Math.random() * stages.length)],
    message: messages[Math.floor(Math.random() * messages.length)],
  }))
}
