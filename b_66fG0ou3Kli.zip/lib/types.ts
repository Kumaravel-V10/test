// Project Types
export type SourceType = 'github' | 'zip'

export interface Project {
  id: string
  name: string
  sourceType: SourceType
  repoUrl?: string
  branch?: string
  createdAt: string
  updatedAt: string
  lastRunAt?: string
  latestGate?: GateDecision
}

// Run Types
export type RunStatus = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled'
export type GateDecision = 'PASS' | 'WARN' | 'BLOCK'
export type StageStatus = 'pending' | 'running' | 'passed' | 'failed' | 'skipped'

export interface Stage {
  name: string
  tool: TestTool
  status: StageStatus
  startedAt?: string
  completedAt?: string
  duration?: number
  error?: string
}

export interface Run {
  id: string
  projectId: string
  projectName: string
  branch: string
  status: RunStatus
  gate?: GateDecision
  stages: Stage[]
  selectedTools: TestTool[]
  createdAt: string
  startedAt?: string
  completedAt?: string
  duration?: number
  config?: Record<string, unknown>
}

// Test Tools
export type TestTool = 
  | 'k6'
  | 'playwright'
  | 'zap'
  | 'newman'
  | 'artillery'
  | 'lighthouse'
  | 'trivy'
  | 'semgrep'

export interface ToolInfo {
  id: TestTool
  name: string
  description: string
  category: 'performance' | 'functional' | 'security' | 'api'
  localModeSupported: boolean
}

export const TOOLS: ToolInfo[] = [
  { id: 'k6', name: 'k6', description: 'Load & performance testing', category: 'performance', localModeSupported: true },
  { id: 'playwright', name: 'Playwright', description: 'E2E browser testing', category: 'functional', localModeSupported: false },
  { id: 'zap', name: 'ZAP', description: 'Dynamic security scanning', category: 'security', localModeSupported: false },
  { id: 'newman', name: 'Newman', description: 'Postman collection runner', category: 'api', localModeSupported: false },
  { id: 'artillery', name: 'Artillery', description: 'Load testing & scenarios', category: 'performance', localModeSupported: false },
  { id: 'lighthouse', name: 'Lighthouse', description: 'Web performance audits', category: 'performance', localModeSupported: false },
  { id: 'trivy', name: 'Trivy', description: 'Vulnerability scanning', category: 'security', localModeSupported: false },
  { id: 'semgrep', name: 'Semgrep', description: 'Static code analysis', category: 'security', localModeSupported: false },
]

// Report Types
export interface ReportSummary {
  totalTests: number
  passed: number
  failed: number
  skipped: number
  duration: number
  gate: GateDecision
}

export interface FunctionalResult {
  suite: string
  test: string
  status: 'passed' | 'failed' | 'skipped'
  duration: number
  error?: string
}

export interface PerformanceMetric {
  name: string
  value: number
  unit: string
  threshold?: number
  status: 'pass' | 'warn' | 'fail'
}

export interface SecurityFinding {
  id: string
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info'
  title: string
  description: string
  location?: string
  recommendation?: string
}

export interface ApiResult {
  endpoint: string
  method: string
  status: number
  duration: number
  assertions: { name: string; passed: boolean }[]
}

export interface GateTrace {
  rule: string
  metric: string
  threshold: number
  actual: number
  result: 'pass' | 'fail'
}

export interface Report {
  runId: string
  summary: ReportSummary
  functional?: FunctionalResult[]
  performance?: PerformanceMetric[]
  security?: SecurityFinding[]
  api?: ApiResult[]
  gateTrace?: GateTrace[]
}

export interface Artifact {
  id: string
  name: string
  type: 'html' | 'json' | 'log' | 'other'
  size: number
  downloadUrl: string
}

// Log Types
export interface LogEntry {
  timestamp: string
  level: 'info' | 'warn' | 'error' | 'debug'
  stage?: string
  message: string
}

// Config Types
export interface ToolConfig {
  tool: TestTool
  enabled: boolean
  config: Record<string, unknown>
}

export interface AppSettings {
  localMode: boolean
  apiBaseUrl: string
  runtimeNotes: string
}
