import useSWR from 'swr'
import useSWRMutation from 'swr/mutation'
import type { Project, Run, Report, Artifact } from './types'
import { mockProjects, mockRuns, mockReport, mockArtifacts } from './mock-data'

// API Base URL - will be configurable in settings
const getBaseUrl = () => {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem('qube-settings')
    if (stored) {
      try {
        const settings = JSON.parse(stored)
        return settings.state?.apiBaseUrl || 'http://localhost:8080'
      } catch {
        return 'http://localhost:8080'
      }
    }
  }
  return 'http://localhost:8080'
}

// Generic fetcher with fallback to mock data
async function fetcher<T>(url: string, mockData: T): Promise<T> {
  try {
    const response = await fetch(`${getBaseUrl()}${url}`, {
      headers: { 'Content-Type': 'application/json' },
    })
    if (!response.ok) throw new Error('API error')
    return response.json()
  } catch {
    // Return mock data when API is unavailable
    console.log('[QUBE] Using mock data for:', url)
    return mockData
  }
}

// Projects
export function useProjects() {
  return useSWR<Project[]>('/projects', () => fetcher('/projects', mockProjects))
}

export function useProject(id: string | undefined) {
  return useSWR<Project | undefined>(
    id ? `/projects/${id}` : null,
    () => fetcher(`/projects/${id}`, mockProjects.find(p => p.id === id))
  )
}

export function useCreateProject() {
  return useSWRMutation('/projects', async (url, { arg }: { arg: Partial<Project> }) => {
    try {
      const response = await fetch(`${getBaseUrl()}${url}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(arg),
      })
      if (!response.ok) throw new Error('Failed to create project')
      return response.json()
    } catch {
      // Mock creation
      const newProject: Project = {
        id: `proj-${Date.now()}`,
        name: arg.name || 'New Project',
        sourceType: arg.sourceType || 'zip',
        repoUrl: arg.repoUrl,
        branch: arg.branch || (arg.sourceType === 'zip' ? 'uploaded' : 'main'),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
      return newProject
    }
  })
}

// Upload
export function useUploadSource() {
  return useSWRMutation(
    '/upload',
    async (_url, { arg }: { arg: { projectId: string; file: File } }) => {
      try {
        const formData = new FormData()
        formData.append('file', arg.file)
        
        const response = await fetch(
          `${getBaseUrl()}/projects/${arg.projectId}/source/upload`,
          { method: 'POST', body: formData }
        )
        if (!response.ok) throw new Error('Upload failed')
        return response.json()
      } catch {
        // Mock upload success
        return { success: true, filename: arg.file.name }
      }
    }
  )
}

// Runs
export function useRuns(projectId?: string) {
  const url = projectId ? `/projects/${projectId}/runs` : '/runs'
  const filtered = projectId 
    ? mockRuns.filter(r => r.projectId === projectId)
    : mockRuns
  return useSWR<Run[]>(url, () => fetcher(url, filtered))
}

export function useRun(runId: string | undefined) {
  return useSWR<Run | undefined>(
    runId ? `/runs/${runId}` : null,
    () => fetcher(`/runs/${runId}`, mockRuns.find(r => r.id === runId))
  )
}

export function useCreateRun() {
  return useSWRMutation(
    '/runs',
    async (_url, { arg }: { arg: { projectId: string; branch: string; tools: string[]; config?: Record<string, unknown> } }) => {
      try {
        const response = await fetch(
          `${getBaseUrl()}/projects/${arg.projectId}/runs`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(arg),
          }
        )
        if (!response.ok) throw new Error('Failed to create run')
        return response.json()
      } catch {
        // Mock run creation
        const project = mockProjects.find(p => p.id === arg.projectId)
        const newRun: Run = {
          id: `run-${Date.now()}`,
          projectId: arg.projectId,
          projectName: project?.name || 'Unknown',
          branch: arg.branch,
          status: 'pending',
          selectedTools: arg.tools as Run['selectedTools'],
          stages: arg.tools.map(tool => ({
            name: tool,
            tool: tool as Run['stages'][0]['tool'],
            status: 'pending' as const,
          })),
          createdAt: new Date().toISOString(),
          config: arg.config,
        }
        return newRun
      }
    }
  )
}

// Reports
export function useReport(runId: string | undefined) {
  return useSWR<Report | undefined>(
    runId ? `/runs/${runId}/report` : null,
    () => fetcher(`/runs/${runId}/report`, { ...mockReport, runId: runId || '' })
  )
}

export function useArtifacts(runId: string | undefined) {
  return useSWR<Artifact[]>(
    runId ? `/runs/${runId}/artifacts` : null,
    () => fetcher(`/runs/${runId}/artifacts`, mockArtifacts)
  )
}
